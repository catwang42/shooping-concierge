from typing import TYPE_CHECKING

from google.genai import types

from .base_tool import BaseTool
from .tool_context import ToolContext

if TYPE_CHECKING:
  from ..models import LlmRequest


class VertexAiSearchTool(BaseTool):

  def __init__(self, data_store_id: str):
    # Name and description are not used because this is a model built-in tool.
    super().__init__(name='vertex_ai_search', description='vertex_ai_search')
    self.data_store_id = data_store_id

  def process_llm_request(
      self,
      tool_context: ToolContext,
      llm_request: 'LlmRequest',
  ):
    if llm_request.model.startswith('gemini-'):
      if llm_request.model.startswith('gemini-1') and llm_request.config.tools:
        raise ValueError(
            'Vertex AI search tool can not be used with other tools in Gemini'
            ' 1.x.'
        )
      llm_request.config.tools.append(
          types.Tool(
              retrieval=types.Retrieval(
                  vertex_ai_search=types.VertexAISearch(
                      datastore=self.data_store_id
                  )
              )
          )
      )
    else:
      raise ValueError(
          'Vertex AI search tool is not supported for model'
          f' {llm_request.model}'
      )
