import abc
from typing import Any
from typing import TYPE_CHECKING

from google.genai import types

from .tool_context import ToolContext

if TYPE_CHECKING:
  from ..models.llm_request import LlmRequest


# We use regular class instead of Pydantic to have better control on computed
# properties.
class BaseTool:
  """Base class for all tools."""

  name: str
  """The name of the tool."""
  description: str
  """The description of the tool."""
  is_long_running: bool = False
  """Whether the tool is async."""

  def __init__(self, name: str, description: str):
    self.name = name
    self.description = description
    self.is_long_running = False

  @abc.abstractmethod
  def get_declaration(self) -> types.FunctionDeclaration:
    pass

  def process_llm_request(
      self, tool_context: ToolContext, llm_request: 'LlmRequest'
  ):
    pass

  @abc.abstractmethod
  def call(self, *, args: dict[str, Any], tool_context: 'ToolContext') -> Any:
    """Call the tool."""
    pass
