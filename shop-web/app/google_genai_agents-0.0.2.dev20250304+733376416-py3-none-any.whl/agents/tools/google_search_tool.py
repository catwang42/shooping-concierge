from typing import TYPE_CHECKING

from google.genai import types

from .base_tool import BaseTool
from .tool_context import ToolContext

if TYPE_CHECKING:
  from ..models import LlmRequest


class GoogleSearchTool(BaseTool):

  def __init__(self):
    # Name and description are not used because this is a model built-in tool.
    super().__init__(name='google_search', description='google_search')

  def process_llm_request(
      self,
      tool_context: ToolContext,
      llm_request: 'LlmRequest',
  ):
    if llm_request.model.startswith('gemini-1'):
      if llm_request.config.tools:
        print(llm_request.config.tools)
        raise ValueError(
            'Google search tool can not be used with other tools in Gemini 1.x.'
        )
      llm_request.config.tools.append(
          types.Tool(google_search_retrieval=types.GoogleSearchRetrieval())
      )
    elif llm_request.model.startswith('gemini-2'):
      llm_request.config.tools.append(
          types.Tool(google_search=types.GoogleSearch())
      )
    else:
      raise ValueError(
          f'Google search tool is not supported for model {llm_request.model}'
      )

google_search_tool = GoogleSearchTool()
