from pydantic import BaseModel
from pydantic import Field


class AuthToolArguments(BaseModel):
  """the arguments for the special long running function tool that is used to

  request end user credentials.
  """

  function_call_event_id: str
  function_call_id: str
  auth_config: dict = Field(default_factory=dict)
