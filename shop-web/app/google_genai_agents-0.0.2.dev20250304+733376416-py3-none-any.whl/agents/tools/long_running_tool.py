from typing import Callable

from pydantic import Field

from .function_tool import FunctionTool


class LongRunningFunctionTool(FunctionTool):
  """A function tool that returns the result asynchronously."""

  def __init__(self, func: Callable):
    super().__init__(func)
    self.is_long_running = True
