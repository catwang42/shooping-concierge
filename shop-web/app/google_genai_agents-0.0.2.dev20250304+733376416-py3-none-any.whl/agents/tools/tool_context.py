from __future__ import annotations

from typing import Any
from typing import TYPE_CHECKING

from ..agents.callback_context import CallbackContext

if TYPE_CHECKING:
  from ..agents.invocation_context import InvocationContext
  from ..events.event_actions import EventActions
  from ..memory.base_memory_service import SearchMemoryResponse


class ToolContext(CallbackContext):

  def __init__(
      self,
      invocation_context: InvocationContext,
      *,
      function_call_event_id: str | None = None,
      function_call_id: str | None = None,
      event_actions: EventActions | None = None,
      auth_response: Any = None,
  ):
    super().__init__(invocation_context, event_actions=event_actions)
    self.function_call_event_id = function_call_event_id
    self.function_call_id = function_call_id
    self.auth_response = auth_response

  @property
  def actions(self) -> EventActions:
    return self._event_actions

  def request_credential(self, auth_config: dict) -> None:
    if not self.function_call_id:
      raise ValueError('function_call_id is not set.')
    self._event_actions.requested_auth_configs[self.function_call_id] = (
        auth_config
    )

  def get_auth_response(self) -> Any:
    return self.auth_response

  def list_artifacts(self) -> list[str]:
    """Lists the filenames of the artifacts attached to the current session."""
    if self._invocation_context.artifact_service is None:
      raise ValueError('Artifact service is not initialized.')
    return self._invocation_context.artifact_service.list_artifact_keys(
        self._invocation_context.app_name,
        self._invocation_context.user_id,
        self._invocation_context.session.id,
    )

  def search_memory(self, query: str) -> 'SearchMemoryResponse':
    """Searches the memory of the current user."""
    if self._invocation_context.memory_service is None:
      raise ValueError('Memory service is not available.')
    return self._invocation_context.memory_service.search_memory(
        self._invocation_context.app_name,
        self._invocation_context.user_id,
        query,
    )
