from typing import TYPE_CHECKING

from .function_tool import FunctionTool
from .tool_context import ToolContext

if TYPE_CHECKING:
  from ..models import LlmRequest
  from ..memory.base_memory_service import MemoryResult


def load_memory(query: str, tool_context: ToolContext) -> 'list[MemoryResult]':
  """Loads the memory for the current user."""
  response = tool_context.search_memory(query)
  return response.memories


class LoadMemoryTool(FunctionTool):

  def __init__(self):
    super().__init__(load_memory)

  def process_llm_request(
      self,
      tool_context: ToolContext,
      llm_request: 'LlmRequest',
  ):
    # Tell the model about the memory.
    llm_request.append_instructions([f"""
You have memory. You can use it to answer questions. If any questions need
you to look up the memory, you should call load_memory function with a query.
"""])


load_memory_tool = LoadMemoryTool()
