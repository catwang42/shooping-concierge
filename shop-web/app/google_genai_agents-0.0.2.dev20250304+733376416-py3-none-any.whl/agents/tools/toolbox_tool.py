import asyncio
from typing import Any

from . import _automatic_function_calling_util
from .langchain_tool import LangchainTool


class ToolboxTool:
  """Use this class to wrap a toolbox tool."""

  toolbox_client: Any

  def __init__(self, url: str):
    from toolbox_langchain import ToolboxClient

    self.toolbox_client = ToolboxClient(url)

  def get_tool(self, tool_name: str) -> LangchainTool:
    tool = asyncio.run(self.toolbox_client.load_tool(tool_name))
    return LangchainTool(tool)

  def get_toolset(self, toolset_name: str) -> list[LangchainTool]:
    tools = asyncio.run(self.toolbox_client.load_toolset(toolset_name))
    return [LangchainTool(tool) for tool in tools]
