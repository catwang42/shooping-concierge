"""Provides data for the agent."""

from typing import Any

from llama_index.core import SimpleDirectoryReader, VectorStoreIndex
from llama_index.core.base.base_retriever import BaseRetriever
from pydantic import Field, model_validator

from .llama_index_retrieval import LlamaIndexRetrieval


class FilesRetrieval(LlamaIndexRetrieval):

  def __init__(self, *, name: str, description: str, input_dir: str):

    self.input_dir = input_dir

    print(f'Loading data from {input_dir}')
    retriever = VectorStoreIndex.from_documents(
        SimpleDirectoryReader(input_dir).load_data()
    ).as_retriever()
    super().__init__(name=name, description=description, retriever=retriever)
