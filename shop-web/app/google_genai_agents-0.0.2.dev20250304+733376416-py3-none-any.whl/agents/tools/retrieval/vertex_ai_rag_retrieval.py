"""A retrieval tool that uses Vertex AI RAG to retrieve data."""

import logging
from typing import Any

from google.genai import types
from vertexai.preview import rag

from ..tool_context import ToolContext
from . import BaseRetrievalTool

logger = logging.getLogger(__name__)


class VertexAiRagRetrieval(BaseRetrievalTool):
  """A retrieval tool that uses Vertex AI RAG (Retrieval-Augmented Generation) to retrieve data."""

  def __init__(
      self,
      *,
      name: str,
      description: str,
      rag_corpora: list[str] = None,
      rag_resources: list[rag.RagResource] = None,
      similarity_top_k: int = None,
      vector_distance_threshold: float = None,
  ):
    super().__init__(name=name, description=description)
    self.vertex_rag_store = types.VertexRagStore(
        rag_corpora=rag_corpora,
        rag_resources=rag_resources,
        similarity_top_k=similarity_top_k,
        vector_distance_threshold=vector_distance_threshold,
    )

  def process_llm_request(
      self,
      tool_context: ToolContext,
      llm_request: 'LlmRequest',
  ):
    # Use Gemini built-in Vertex AI RAG tool for Gemini 2 models.
    if llm_request.model.startswith('gemini-2'):
      llm_request.config.tools.append(
          types.Tool(
              retrieval=types.Retrieval(vertex_rag_store=self.vertex_rag_store)
          )
      )
    else:
      # Add the function declaration to the tools
      found_function_declarations = False
      for index, tool in enumerate(llm_request.config.tools):
        if tool.function_declarations:
          llm_request.config.tools[index].function_declarations.append(
              super().get_declaration()
          )
          found_function_declarations = True
          break
      if not found_function_declarations:
        llm_request.config.tools.append(
            types.Tool(function_declarations=[super().get_declaration()])
        )
      llm_request.tools_dict[self.name] = self

  def get_declaration(self) -> types.FunctionDeclaration:
    # Defer adding the function declaration until the request is processed.
    return None

  def call(
      self,
      *,
      args: dict[str, Any],
      tool_context: ToolContext,
  ) -> Any:

    response = rag.retrieval_query(
        text=args['query'],
        rag_resources=self.vertex_rag_store.rag_resources,
        rag_corpora=self.vertex_rag_store.rag_corpora,
        similarity_top_k=self.vertex_rag_store.similarity_top_k,
        vector_distance_threshold=self.vertex_rag_store.vector_distance_threshold,
    )

    logging.debug('RAG raw response: %s', response)

    return (
        f'No matching result found with the config: {self.vertex_rag_store}'
        if not response.contexts.contexts
        else [context.text for context in response.contexts.contexts]
    )
