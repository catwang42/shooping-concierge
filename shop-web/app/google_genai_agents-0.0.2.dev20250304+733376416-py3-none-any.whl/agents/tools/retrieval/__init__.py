import logging
from .base_retrieval_tool import BaseRetrievalTool
from .files_retrieval import FilesRetrieval
from .llama_index_retrieval import LlamaIndexRetrieval

logger = logging.getLogger(__name__)

__all__ = [
    'BaseRetrievalTool',
    'FilesRetrieval',
    'LlamaIndexRetrieval',
]

try:
  from .vertex_ai_rag_retrieval import VertexAiRagRetrieval

  __all__.append('VertexAiRagRetrieval')
except ImportError:
  logger.warning(
      'The Vertex sdk is not installed. If you want to use the Vertex RAG with'
      ' agents, please install it. If not, you can ignore this warning.'
  )
