"""An artifact service implementation using Google Cloud Storage (GCS)."""

import logging

from google.cloud import storage
from google.genai import types

from .base_artifact_service import BaseArtifactService

logger = logging.getLogger(__name__)


class GcsArtifactService(BaseArtifactService):

  def __init__(self, bucket_name: str, **kwargs):
    super().__init__(**kwargs)
    self.bucket_name = bucket_name
    self.storage_client = storage.Client()
    self.bucket = self.storage_client.bucket(self.bucket_name)

  def _file_has_user_namespace(self, filename: str) -> bool:
    # If filename has a user namespace, it will be in the format of
    # user:{filename}.
    return filename.startswith("user:")

  def _get_blob_name(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      filename: str,
      version: int,
  ) -> str:
    """Constructs the blob name in GCS."""
    if self._file_has_user_namespace(filename):
      return f"{app_name}/{user_id}/user/{filename}/{version}"
    return f"{app_name}/{user_id}/{session_id}/{filename}/{version}"

  def save_artifact(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      filename: str,
      artifact: types.Part,
  ) -> int:
    """Saves an artifact."""
    versions = self.list_versions(app_name, user_id, session_id, filename)
    version = 0 if not versions else max(versions) + 1

    blob_name = self._get_blob_name(
        app_name, user_id, session_id, filename, version
    )
    blob = self.bucket.blob(blob_name)

    blob.upload_from_string(
        data=artifact.inline_data.data,
        content_type=artifact.inline_data.mime_type,
    )

    return version

  def load_artifact(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      filename: str,
      version: int | None = None,
  ) -> types.Part | None:
    """Loads an artifact from GCS."""
    if version is None:
      versions = self.list_versions(app_name, user_id, session_id, filename)
      if not versions:
        return None
      version = max(versions)

    blob_name = self._get_blob_name(
        app_name, user_id, session_id, filename, version
    )
    blob = self.bucket.blob(blob_name)

    artifact_bytes = blob.download_as_bytes()
    if not artifact_bytes:
      return None
    artifact = types.Part.from_bytes(
        data=artifact_bytes, mime_type=blob.content_type
    )
    return artifact

  def list_artifact_keys(
      self, app_name: str, user_id: str, session_id: str
  ) -> list[str]:
    """Lists all artifact filenames within a session from GCS."""
    filenames = set()

    session_prefix = f"{app_name}/{user_id}/{session_id}/"
    session_blobs = self.storage_client.list_blobs(
        self.bucket, prefix=session_prefix
    )
    for blob in session_blobs:
      _, _, _, filename, _ = blob.name.split("/")
      filenames.add(filename)

    user_namespace_prefix = f"{app_name}/{user_id}/user/"
    user_namespace_blobs = self.storage_client.list_blobs(
        self.bucket, prefix=user_namespace_prefix
    )
    for blob in user_namespace_blobs:
      _, _, _, filename, _ = blob.name.split("/")
      filenames.add(filename)

    return sorted(list(filenames))

  def delete_artifact(
      self, app_name: str, user_id: str, session_id: str, filename: str
  ) -> None:
    """Deletes an artifact from GCS."""
    versions = self.list_versions(app_name, user_id, session_id, filename)
    for version in versions:
      blob_name = self._get_blob_name(
          app_name, user_id, session_id, filename, version
      )
      blob = self.bucket.blob(blob_name)
      blob.delete()
    return

  def list_versions(
      self, app_name: str, user_id: str, session_id: str, filename: str
  ) -> list[int]:
    """Lists all versions of an artifact from GCS."""
    prefix = self._get_blob_name(app_name, user_id, session_id, filename, "")
    blobs = self.storage_client.list_blobs(self.bucket, prefix=prefix)
    versions = []
    for blob in blobs:
      _, _, _, _, version = blob.name.split("/")
      versions.append(int(version))
    return versions
