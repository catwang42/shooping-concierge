from abc import ABC
from abc import abstractmethod

from google.genai import types


class BaseArtifactService(ABC):
  """The interface for the artifact service."""

  @abstractmethod
  def save_artifact(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      filename: str,
      artifact: types.Part,
  ) -> int:
    """Saves an artifact.

    Args:
      app_name: The app name.
      user_id: The user ID.
      session_id: The session ID.
      filename: The filename of the artifact.
      artifact: The artifact to save.

    Returns:
      The revision ID.
    """

  @abstractmethod
  def load_artifact(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      filename: str,
      version: int | None = None,
  ) -> types.Part | None:
    """Gets an artifact.

    Args:
      app_name: The app name.
      user_id: The user ID.
      session_id: The session ID.
      filename: The filename of the artifact.
      version: The version of the artifact. If None, the latest version will be
        returned.

    Returns:
      The artifact or None if not found.
    """
    pass

  @abstractmethod
  def list_artifact_keys(
      self, app_name: str, user_id: str, session_id: str
  ) -> list[str]:
    """Lists all the artifact filenames within a session."""
    pass

  @abstractmethod
  def delete_artifact(
      self, app_name: str, user_id: str, session_id: str, filename: str
  ) -> None:
    """Deletes an artifact."""
    pass

  @abstractmethod
  def list_versions(
      self, app_name: str, user_id: str, session_id: str, filename: str
  ) -> list[int]:
    """Lists all the versions of an artifact."""
    pass
