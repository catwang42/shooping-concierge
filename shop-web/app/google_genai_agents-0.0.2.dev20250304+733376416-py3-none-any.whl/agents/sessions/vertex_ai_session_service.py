from datetime import datetime
import logging
import time
from typing import Any
from typing import Optional

from google import genai

from .base_session_service import BaseSessionService
from .base_session_service import GetSessionConfig
from .base_session_service import ListEventsConfig
from .base_session_service import ListEventsResponse
from .base_session_service import ListSessionsResponse
from .session import Session

logger = logging.getLogger(__name__)


class VertexAiSessionService(BaseSessionService):
  """Connects to the managed Vertex AI Session Service."""

  def __init__(
      self,
      project: str = None,
      location: str = None,
  ):
    self.project = project
    self.location = location

    client = genai.Client(vertexai=True, project=project, location=location)
    self.api_client = client._api_client

  def create_session(
      self,
      app_name: str,
      user_id: str,
      state: Optional[dict[str, Any]] = None,
      *,
      session_id: Optional[str] = None,
  ) -> Session:
    reasoning_engine_id = _parse_reasoning_engine_id(app_name)

    session_json_dict = {}
    if state:
      session_json_dict['session_state'] = state

    api_response = self.api_client.request(
        http_method='POST',
        path=f'reasoningEngines/{reasoning_engine_id}/sessions',
        request_dict=session_json_dict,
    )
    logger.info(f'Create Session response {api_response}')

    session_id = api_response['name'].split('/')[-3]
    operation_id = api_response['name'].split('/')[-1]

    max_retry_attempt = 5
    while max_retry_attempt >= 0:
      lro_response = self.api_client.request(
          http_method='GET',
          path=f'operations/{operation_id}',
          request_dict={},
      )

      if lro_response.get('done', None):
        break

      time.sleep(1)
      max_retry_attempt -= 1

    session = Session(
        app_name=app_name, user_id=user_id, id=session_id, state=state
    )
    return session

  def get_session(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      config: GetSessionConfig | None = None,
  ) -> Session | None:
    reasoning_engine_id = _parse_reasoning_engine_id(app_name)

    # Get session resource
    get_session_api_response = self.api_client.request(
        http_method='GET',
        path=f'reasoningEngines/{reasoning_engine_id}/sessions/{session_id}',
        request_dict={},
    )

    session_id = get_session_api_response['name'].split('/')[-1]

    update_time_string = get_session_api_response['updateTime']
    update_timestamp = datetime.strptime(
        update_time_string, '%Y-%m-%dT%H:%M:%S.%fZ'
    ).timestamp()
    session = Session(
        app_name=str(app_name),
        user_id=str(user_id),
        id=str(session_id),
        state=get_session_api_response.get('sessionState', {}),
        last_update_time=update_timestamp,
    )

    # TODO: merge list events response
    return session

  def list_sessions(self, app_name: str, user_id: str) -> ListSessionsResponse:
    reasoning_engine_id = _parse_reasoning_engine_id(app_name)

    api_response = self.api_client.request(
        http_method='GET',
        path=f'reasoningEngines/{reasoning_engine_id}/sessions',
        # TODO: pass in user id filter
        request_dict={},
    )

    session_ids = [
        session['name'].split('/')[-1] for session in api_response['sessions']
    ]

    response = ListSessionsResponse(session_ids=session_ids)
    return response

  def delete_session(
      self, app_name: str, user_id: str, session_id: str
  ) -> None:
    reasoning_engine_id = _parse_reasoning_engine_id(app_name)
    self.api_client.request(
        http_method='DELETE',
        path=f'reasoningEngines/{reasoning_engine_id}/sessions/{session_id}',
        request_dict={},
    )

  def list_events(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      config: ListEventsConfig,
  ) -> ListEventsResponse:
    reasoning_engine_id = _parse_reasoning_engine_id(app_name)
    api_response = self.api_client.request(
        http_method='GET',
        path=f'reasoningEngines/{reasoning_engine_id}/sessions/{session_id}/events',
        request_dict={},
    )

    logger.info(f'List events response {api_response}')

    # TODO: convert event response into Event objects


def _parse_reasoning_engine_id(app_name: str):
  return app_name
