from typing import Any

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field

from ..events import Event


class Session(BaseModel):
  model_config = ConfigDict(
      extra='forbid',
      arbitrary_types_allowed=True,
  )
  # TODO: Makes this required.
  id: str = ''
  app_name: str
  user_id: str
  state: dict[str, Any] = Field(default_factory=dict)
  """The state of the session."""

  events: list[Event] = Field(default_factory=list)
  """The events of the session, e.g. user input, model response, function
  call/response, etc
  """

  last_update_time: float = 0.0
