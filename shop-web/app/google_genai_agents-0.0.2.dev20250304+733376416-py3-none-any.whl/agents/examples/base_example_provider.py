from .example import Example


# A class that provides examples for a given query.
class BaseExampleProvider:
  def get_examples(self, query: str) -> list[Example]:
    raise NotImplementedError()
