from google.genai import types
from pydantic import BaseModel


# An few-shot example.
class Example(BaseModel):
  input: types.Content
  output: list[types.Content]
