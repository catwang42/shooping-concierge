from typing import Callable
from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field
from ..tools.base_tool import BaseTool
from ..tools.function_tool import FunctionTool


class LlmRequest(BaseModel):
  model_config = ConfigDict(arbitrary_types_allowed=True)

  model: str | None = None
  contents: list[types.Content] = Field(default_factory=list)
  config: types.GenerateContentConfig | None = None
  """Additional config for the generate content request.

  tools in generate_content_config should not be set.
  """
  tools_dict: dict[str, BaseTool] = Field(default_factory=dict, exclude=True)

  def append_instructions(self, instructions: list[str]) -> None:
    if self.config.system_instruction:
      self.config.system_instruction += '\n\n' + '\n\n'.join(instructions)
    else:
      self.config.system_instruction = '\n\n'.join(instructions)

  def append_tools(self, tools: list[BaseTool | Callable]) -> None:
    if not tools:
      return
    declarations = []
    for tool in tools:
      if isinstance(tool, Callable):
        tool = FunctionTool(tool)
      declaration = tool.get_declaration()
      if declaration:
        declarations.append(declaration)
        self.tools_dict[tool.name] = tool
    if declarations:
      self.config.tools.append(types.Tool(function_declarations=declarations))

  def set_output_schema(self, base_model: type[BaseModel]) -> None:
    self.config.response_schema = base_model
    self.config.response_mime_type = 'application/json'
