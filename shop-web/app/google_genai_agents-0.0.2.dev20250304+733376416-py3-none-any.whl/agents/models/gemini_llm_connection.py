from typing import AsyncGenerator

from google.genai import live
from google.genai import types

from .base_llm_connection import BaseLlmConnection
from .llm_response import LlmResponse


class GeminiLlmConnection(BaseLlmConnection):
  """The Gemini model connection."""

  def __init__(self, gemini_session: live.AsyncSession):
    self._gemini_session = gemini_session

  async def send_history(self, history: list[types.Content]):
    # TODO: Remove this filter and translate unary contents to streaming
    # contents properly.
    contents = [
        content
        for content in history
        if content.parts and content.parts[0].text
    ]
    await self._gemini_session.send(
        input=types.LiveClientContent(
            turns=contents,
            turn_complete=contents[-1].role == 'user',
        ),
    )

  async def send_content(self, content: types.Content):
    assert content.parts
    if content.parts[0].function_response:
      # All parts have to be function responses.
      function_responses = [part.function_response for part in content.parts]
      await self._gemini_session.send(
          input=types.LiveClientToolResponse(
              function_responses=function_responses
          ),
      )
    else:
      await self._gemini_session.send(
          input=types.LiveClientContent(
              turns=[content],
              turn_complete=True,
          )
      )

  async def send_realtime(self, blob: types.Blob):
    await self._gemini_session.send(input=blob.model_dump())

  def __build_text_response(self, text: str):
    return LlmResponse(
        content=types.Content(
            role='model',
            parts=[types.Part.from_text(text=text)],
        ),
    )

  async def receive(self) -> AsyncGenerator[LlmResponse, None]:
    text = ''
    async for message in self._gemini_session.receive():
      if message.server_content:
        content = message.server_content.model_turn
        if content and content.parts:
          llm_response = LlmResponse(
              content=content, interrupted=message.server_content.interrupted
          )
          if content.parts[0].text:
            text += content.parts[0].text
            llm_response.partial = True
          else:
            if text:
              yield self.__build_text_response(text)
              text = ''
          yield llm_response

        if message.server_content.turn_complete:
          if text:
            yield self.__build_text_response(text)
            text = ''
          yield LlmResponse(turn_complete=True)
          break
      if message.tool_call:
        if text:
          yield self.__build_text_response(text)
          text = ''
        parts = [
            types.Part(function_call=function_call)
            for function_call in message.tool_call.function_calls
        ]
        yield LlmResponse(content=types.Content(role='model', parts=parts))

  async def close(self):
    await self._gemini_session.close()
