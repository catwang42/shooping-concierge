import contextlib
from functools import cached_property
import logging
from typing import AsyncGenerator
from typing import cast
from typing import Generator

from google.genai import Client
from google.genai import types
from typing_extensions import override

from .base_llm import BaseLlm
from .base_llm import LlmRequest
from .base_llm import LlmResponse
from .base_llm_connection import BaseLlmConnection
from .gemini_llm_connection import GeminiLlmConnection

logger = logging.getLogger(__name__)
line_break = '\n'
_EXCLUDED_PART_FIELD = {'inline_data': {'data'}}


class Gemini(BaseLlm):
  """Integration for Gemini models."""

  model: str = 'gemini-1.5-flash'

  @staticmethod
  @override
  def supported_models() -> list[str]:
    return [
        r'gemini-.*',
        r'projects\/.+\/locations\/.+\/endpoints\/.+',  # fine-tuned vertex endpoint pattern
        r'projects\/.+\/locations\/.+\/publishers\/google\/models\/gemini.+',  # vertex gemini long name
    ]

  def generate_content(
      self, llm_request: LlmRequest, stream: bool = False
  ) -> Generator[types.GenerateContentResponse, None, None]:
    self._maybe_append_user_content(llm_request)
    logger.info(
        'Sending out request, model: %s, backend: %s, stream: %s',
        llm_request.model,
        self._api_backend,
        stream,
    )
    logger.info(_build_request_log(llm_request))

    if stream:
      responses = self.api_client.models.generate_content_stream(
          model=llm_request.model,
          contents=llm_request.contents,
          config=llm_request.config,
      )
      for response in responses:
        logger.info(_build_response_log(response))
        # TODO: Handle partial response.
        yield LlmResponse.create(response)
    else:
      response = self.api_client.models.generate_content(
          model=llm_request.model,
          contents=llm_request.contents,
          config=llm_request.config,
      )
      logger.info(_build_response_log(response))
      yield LlmResponse.create(response)

  async def generate_content_async(
      self, llm_request: LlmRequest, stream: bool = False
  ) -> AsyncGenerator[LlmResponse, None]:
    self._maybe_append_user_content(llm_request)
    logger.info(
        'Sending out request, model: %s, backend: %s, stream: %s',
        llm_request.model,
        self._api_backend,
        stream,
    )
    logger.info(_build_request_log(llm_request))

    if not stream:
      response = await self.api_client.aio.models.generate_content(
          model=llm_request.model,
          contents=llm_request.contents,
          config=llm_request.config,
      )
      logger.info(_build_response_log(response))
      yield LlmResponse.create(response)
    else:
      raise NotImplementedError('Streaming call is not supported for async.')

  @cached_property
  def api_client(self) -> Client:
    return Client()

  @cached_property
  def _api_backend(self) -> str:
    return 'vertex' if self.api_client.vertexai else 'ml_dev'

  @contextlib.asynccontextmanager
  async def connect(self, llm_request: LlmRequest) -> BaseLlmConnection:
    api_version = 'internal' if self._api_backend == 'vertex' else 'v1alpha'
    client = Client(http_options={'api_version': api_version})
    config = types.LiveConnectConfig(
        response_modalities=llm_request.config.response_modalities,
        system_instruction=types.Content(
            role='system',
            parts=[
                types.Part.from_text(text=llm_request.config.system_instruction)
            ],
        ),
        tools=llm_request.config.tools,
    )
    async with client.aio.live.connect(
        # We use Gemini 2.0 regardless of the agent's model config.
        model='gemini-2.0-flash-exp',
        config=config,
    ) as live_session:
      yield GeminiLlmConnection(live_session)

  def _maybe_append_user_content(self, llm_request: LlmRequest):
    """Appends a user content, so that model can continue to output."""
    # Last content must be from the user, otherwise the model won't respond.
    if not llm_request.contents or llm_request.contents[-1].role != 'user':
      # TODO: expose this sentence to be configuration to user.
      llm_request.contents.append(
          types.Content(
              role='user',
              parts=[
                  types.Part(
                      text=(
                          'Continue output. DO NOT look at this line. ONLY look'
                          ' at the content before this line and system'
                          ' instruction. '
                      )
                  )
              ],
          )
      )


def _build_function_declaration_log(
    func_decl: types.FunctionDeclaration,
) -> str:
  param_str = '{}'
  if func_decl.parameters and func_decl.parameters.properties:
    param_str = str({
        k: v.model_dump(exclude_none=True)
        for k, v in func_decl.parameters.properties.items()
    })
  return_str = 'None'
  if func_decl.response:
    return_str = str(func_decl.response.model_dump(exclude_none=True))
  return f'{func_decl.name}: {param_str} -> {return_str}'


def _build_request_log(req: LlmRequest) -> str:
  function_decls: list[types.FunctionDeclaration] = cast(
      list[types.FunctionDeclaration],
      req.config.tools[0].function_declarations if req.config.tools else [],
  )
  function_logs = (
      [
          _build_function_declaration_log(func_decl)
          for func_decl in function_decls
      ]
      if function_decls
      else []
  )
  contents_logs = [
      content.model_dump_json(
          exclude_none=True,
          exclude={
              'parts': {
                  i: _EXCLUDED_PART_FIELD for i in range(len(content.parts))
              }
          },
      )
      for content in req.contents
  ]

  return f"""Request:
-----------------------------------------------------------
System Instruction:
{req.config.system_instruction}
-----------------------------------------------------------
Contents:
{line_break.join(contents_logs)}
-----------------------------------------------------------
Functions:
{line_break.join(function_logs)}
-----------------------------------------------------------
"""


def _build_response_log(resp: types.GenerateContentResponse) -> str:
  return f"""Response:
-----------------------------------------------------------
{resp.model_dump_json(exclude_none=True)}
-----------------------------------------------------------
"""
