"""Handles NL planning related logic."""

from ...agents.callback_context import CallbackContext
from ...agents.invocation_context import InvocationContext
from ...agents.readonly_context import ReadonlyContext
from ...models import LlmRequest
from ...models import LlmResponse
from ...planner.base_planner import BasePlanner
from ...planner.plan_re_act_planner import PlanReActPlanner


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):
  planner = _get_planner(invocation_context)
  if not planner:
    return

  planning_instruction = planner.build_planning_instruction(
      ReadonlyContext(invocation_context), llm_request
  )
  if planning_instruction:
    llm_request.append_instructions([planning_instruction])


def process_llm_response(
    invocation_context: InvocationContext,
    llm_response: LlmResponse,
):
  if (
      not llm_response
      or not llm_response.content
      or not llm_response.content.parts
  ):
    return

  planner = _get_planner(invocation_context)
  if not planner:
    return

  # Postprocess the LLM response.
  processed_parts = planner.process_planning_response(
      CallbackContext(invocation_context), llm_response.content.parts
  )
  if processed_parts:
    llm_response.content.parts = processed_parts


def _get_planner(invocation_context: InvocationContext) -> BasePlanner | None:
  if not invocation_context.agent or not invocation_context.agent.planning:
    return None

  if isinstance(invocation_context.agent.planning, BasePlanner):
    return invocation_context.agent.planning
  return PlanReActPlanner()
