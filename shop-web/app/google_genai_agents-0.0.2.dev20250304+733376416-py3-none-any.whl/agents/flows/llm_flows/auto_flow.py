"""Implementation of AutoFlow."""

from . import agent_transfer
from .single_flow import SingleFlow


class AutoFlow(SingleFlow):
  """AutoFlow is SingleFlow with agent transfer capability.

  Agent transfer is allowed in the following direction:

  1. from parent to child;
  2. from child to parent;
  3. from child to its sibling;

  For sibling transfers, it's only enabled when all below conditions are met:

  - The parent agent is also of AutoFlow;
  - `disable_sibling_agent_transfer` option of this agent is False (default).

  Depending on the target agent flow type, the transfer may be automatically
  reversed. The condition is as below:

  - If the flow type of the tranferee agent is also auto, transfee agent will
    remain as the active agent. The transfee agent will respond to the user's
    next message directly.
  - If the flow type of the transfere agent is not auto, the active agent will
    be reversed back to previous agent.

  TODO: allow user to config auto-reverse function.
  """

  def __init__(self):
    super().__init__()
    self.request_processors += [agent_transfer]
