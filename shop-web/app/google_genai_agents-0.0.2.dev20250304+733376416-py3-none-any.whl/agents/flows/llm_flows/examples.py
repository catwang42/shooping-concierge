"""Handles examples for LLM flow."""

from ...agents.invocation_context import InvocationContext
from ...examples import example_util
from ...models import LlmRequest


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):
  if not invocation_context.agent.examples:
    return
  llm_request.append_instructions(
      [example_util.build_example_si(invocation_context)]
  )
