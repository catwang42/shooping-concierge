"""Handles instructions and global instructions for LLM flow."""

from __future__ import annotations

import re
from typing import Callable
from typing import TYPE_CHECKING

from ...agents.readonly_context import ReadonlyContext
from ...sessions import State

if TYPE_CHECKING:

  from ...agents.agent import Agent
  from ...agents.agent import InstructionProvider
  from ...agents.invocation_context import InvocationContext
  from ...models import LlmRequest


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
) -> None:
  agent: Agent = invocation_context.agent

  # Appends global instructions if set.
  root_agent: Agent = invocation_context.agent.get_root_agent()
  if root_agent.global_instruction:
    si = _build_system_instruction(
        invocation_context, root_agent.global_instruction
    )
    llm_request.append_instructions([si])

  # Appends agent instructions if set.
  if agent.instruction:
    si = _build_system_instruction(invocation_context, agent.instruction)
    llm_request.append_instructions([si])


def _build_system_instruction(
    invocation_context: InvocationContext,
    instruction: str | InstructionProvider,
) -> str:
  """Builds system instruction from instruction and session."""
  if isinstance(instruction, Callable):

    si = instruction(ReadonlyContext(invocation_context))
  else:
    si = instruction
  return _populate_values(si, invocation_context)


def _populate_values(
    instruction_template: str,
    context: InvocationContext,
) -> str:
  def _replace_match(match) -> str:
    var_name = match.group().lstrip('{').rstrip('}').strip()
    optional = False
    if var_name.endswith('?'):
      optional = True
      var_name = var_name.removesuffix('?')
    if var_name.startswith('artifact.'):
      var_name = var_name.removeprefix('artifact.')
      if context.artifact_service is None:
        raise ValueError('Artifact service is not initialized.')
      artifact = context.artifact_service.load_artifact(
          context.session.app_name,
          context.session.user_id,
          context.session.id,
          var_name,
      )
      if not var_name:
        raise KeyError(f'Artifact {var_name} not found.')
      return str(artifact)
    else:
      if not _is_valid_state_name(var_name):
        return match.group()
      if var_name in context.session.state:
        return str(context.session.state[var_name])
      else:
        if optional:
          return ''
        else:
          raise KeyError(f'Context variable {var_name} not found.')

  return re.sub(r'{+[^{}]*}+', _replace_match, instruction_template)


def _is_valid_state_name(var_name):
  """Checks if the variable name is a valid state name.

  Valid state is either:
    - Valid identifier
    - <Valid prefix>:<Valid identifier>
  All the others will just return as it is.

  Args:
    var_name: The variable name to check.

  Returns:
    True if the variable name is a valid state name, False otherwise.
  """
  parts = var_name.split(':')
  if len(parts) == 1:
    return var_name.isidentifier()

  if len(parts) == 2:
    prefixes = [State.APP_PREFIX, State.USER_PREFIX, State.TEMP_PREFIX]
    if (parts[0] + ':') in prefixes:
      return parts[1].isidentifier()
  return False
