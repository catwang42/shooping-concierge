"""Handles basic information to build the LLM request."""

from ...agents.invocation_context import InvocationContext
from ...models import LlmRequest
from ...tools import AuthToolArguments
from . import functions
from .functions import REQUEST_EUC_FUNCTION_CALL_NAME


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):

  events = invocation_context.session.events
  if not events:
    return
  request_euc_function_call_response_event = events[-1]
  responses = request_euc_function_call_response_event.get_function_responses()
  if not responses:
    return

  auth_responses_by_long_running_tool_id = {}
  reqeust_euc_function_call_event_id = None
  for function_call_response in responses:
    if function_call_response.name != REQUEST_EUC_FUNCTION_CALL_NAME:
      continue
    if not reqeust_euc_function_call_event_id:
      reqeust_euc_function_call_event_id = (
          request_euc_function_call_response_event.function_call_event_id
      )
    auth_responses_by_long_running_tool_id[function_call_response.id] = (
        function_call_response.response
    )
  if not reqeust_euc_function_call_event_id:
    return

  for i in range(len(events) - 2, -1, -1):
    event = events[i]
    # found the system long running reqeust euc function call
    if event.id == reqeust_euc_function_call_event_id:
      auth_responses_by_tool_id = {}
      function_call_event_id = None
      for function_call in event.get_function_calls():
        if function_call.id not in auth_responses_by_long_running_tool_id:
          continue
        args = AuthToolArguments.model_validate(function_call.args)
        if not function_call_event_id:
          function_call_event_id = args.function_call_event_id
        function_call_id = args.function_call_id
        auth_responses_by_tool_id[function_call_id] = (
            auth_responses_by_long_running_tool_id[function_call.id]
        )
      if not function_call_event_id:
        return

      for j in range(i - 1, -1, -1):
        event = events[j]
        if event.id != function_call_event_id:
          continue

        function_response_event = functions.handle_function_calls(
            invocation_context,
            event,
            llm_request.tools_dict,
            # there could be parallel function calls that require auth
            # auth response would be a dict keyed by function call id
            auth_responses_by_tool_id,
        )
        if function_response_event:
          yield function_response_event
        break

      return
