from .base_flow import BaseFlow
from .llm_flows.auto_flow import AutoFlow
from .llm_flows.single_flow import SingleFlow
from .loop_flow import LoopFlow
from .parallel_flow import ParallelFlow
from .registry import FlowRegistry
from .sequential_flow import SequentialFlow

__all__ = [
    'AutoFlow',
    'BaseFlow',
    'FlowRegistry',
    'LoopFlow',
    'ParallelFlow',
    'SequentialFlow',
    'SingleFlow',
]


FlowRegistry.register('auto', AutoFlow)
FlowRegistry.register('loop', LoopFlow)
FlowRegistry.register('parallel', ParallelFlow)
FlowRegistry.register('sequential', SequentialFlow)
FlowRegistry.register('single', SingleFlow)
