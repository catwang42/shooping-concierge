"""The registry class for flows."""

import typing
from abc import ABC

if typing.TYPE_CHECKING:
  from .base_flow import BaseFlow


_flow_registry_dict: dict[str, type['BaseFlow']] = {}


class FlowRegistry(ABC):
  """Registry for the flow."""

  @staticmethod
  def new_flow(flow_name: str) -> 'BaseFlow':
    if flow_name not in _flow_registry_dict:
      raise ValueError(f'Flow {flow_name} not found.')

    return _flow_registry_dict[flow_name]()

  @staticmethod
  def register(flow_name: str, subclass: type['BaseFlow']):
    if flow_name in _flow_registry_dict:
      raise ValueError(f'Flow {flow_name} already exists.')

    _flow_registry_dict[flow_name] = subclass

  @staticmethod
  def resolve(flow_name: str) -> type['BaseFlow']:
    if flow_name not in _flow_registry_dict:
      raise ValueError(f'Flow {flow_name} not found.')
    return _flow_registry_dict[flow_name]
