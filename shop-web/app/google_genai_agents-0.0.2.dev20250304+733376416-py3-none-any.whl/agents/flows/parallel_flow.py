from __future__ import annotations

import asyncio
from dataclasses import dataclass
import logging
from typing import AsyncGenerator
from typing import cast
from typing import Generator
from typing import TYPE_CHECKING
from venv import logger

from typing_extensions import override

from ..agents.invocation_context import InvocationContext
from ..events import Event
from .base_flow import BaseFlow

if TYPE_CHECKING:
  from ..agents.agent import Agent
  from ..agents.base_agent import BaseAgent


__all__ = ["ParallelFlow"]

logger = logging.getLogger(__name__)


def _set_branch_for_current_agent(
    current_agent: BaseAgent, invocation_context: InvocationContext
):
  invocation_context.branch = (
      f"{invocation_context.branch}.{current_agent.name}"
      if invocation_context.branch
      else current_agent.name
  )


async def _merge_agent_run(
    agent_runs: list[AsyncGenerator[Event, None]],
) -> AsyncGenerator[Event, None]:
  """Merges the agent run event generator.

  This implementation guarantees for each agent, it won't move on until the
  generated event is processed by upstream runner.
  """
  tasks = [
      asyncio.create_task(anext(events_for_one_agent))
      for events_for_one_agent in agent_runs
  ]
  pending_tasks = set(tasks)

  while pending_tasks:
    done, pending_tasks = await asyncio.wait(
        pending_tasks, return_when=asyncio.FIRST_COMPLETED
    )
    for task in done:
      try:
        yield task.result()

        # Find the generator that produced this event and move it on.
        for i, original_task in enumerate(tasks):
          if task == original_task:
            new_task = asyncio.create_task(anext(agent_runs[i]))
            tasks[i] = new_task
            pending_tasks.add(new_task)
            break  # stop iterating once found

      except StopAsyncIteration:
        continue


class ParallelFlow(BaseFlow):
  """Runs children in parallel."""

  @override
  def __call__(
      self, invocation_context: InvocationContext
  ) -> Generator[Event, None, None]:
    logger.warning(
        "Running ParallelFlow in sync mode. Only keep the parallel behavior"
        " without concurrently running."
    )

    from ..agents.agent import Agent

    current_agent: Agent = cast(Agent, invocation_context.agent)
    _set_branch_for_current_agent(current_agent, invocation_context)

    for child in current_agent.children:
      yield from child.run(invocation_context)

  @override
  async def run_async(
      self, invocation_context: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    from ..agents.agent import Agent

    current_agent: Agent = cast(Agent, invocation_context.agent)
    _set_branch_for_current_agent(current_agent, invocation_context)

    agent_runs = [
        agent.run_async(invocation_context) for agent in current_agent.children
    ]

    async for event in _merge_agent_run(agent_runs):
      yield event
