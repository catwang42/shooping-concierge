from typing import AsyncGenerator
from typing import Generator

from typing_extensions import override

from ..agents.invocation_context import InvocationContext
from ..events import Event
from .base_flow import BaseFlow


class SequentialFlow(BaseFlow):

  def __call__(
      self,
      invocation_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    for child in invocation_context.agent.children:
      yield from child.run(invocation_context)

  @override
  async def run_async(
      self, invocation_context: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    raise NotImplementedError(f'run_async is not implemented for {type(self)}')
