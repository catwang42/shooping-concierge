from abc import ABC
from abc import abstractmethod
from typing import AsyncGenerator
from typing import Generator

from ..agents.invocation_context import InvocationContext
from ..events import Event


class BaseFlow(ABC):
  """Interface for the execution flows to run a group of agents."""

  @abstractmethod
  def __call__(
      self, invocation_context: InvocationContext
  ) -> Generator[Event, None, None]:
    """Run this flow in synchronous mode.

    To extend, the flow should follow the below requirements:

    1. `session` should be treated as immutable, DO NOT change it.

    2. The caller who trigger the flow is responsible for updating the session
    as the events being generated. The subclass implentation will assume
    session is updated after each yield event statement.

    3. A flow may spawn children flows dependeing on the agent definition.
    """

  # TODO(weisun): make this the default and add document here, make __call__ a
  #   syntax sugar.
  def run(
      self, invocation_context: InvocationContext
  ) -> Generator[Event, None, None]:
    yield from self(invocation_context)

  @abstractmethod
  async def run_async(
      self, invocation_context: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    ...
