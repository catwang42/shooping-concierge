from pydantic import BaseModel
from pydantic import Field

from ..events.event import Event
from ..sessions import Session


class MemoryResult(BaseModel):
  session_id: str
  events: list[Event]


class SearchMemoryResponse(BaseModel):
  memories: list[MemoryResult] = Field(default_factory=list)


class BaseMemoryService:
  """Base class for memory services."""

  def add_session_to_memory(self, session: Session):
    """Adds a session to the memory service.

    A session may be added multiple times during its lifetime.

    Args:
        session: The session to add.
    """
    raise NotImplementedError()

  def search_memory(
      self, app_name: str, user_id: str, query: str
  ) -> SearchMemoryResponse:
    """Searches for sessions that match the query."""
    raise NotImplementedError()
