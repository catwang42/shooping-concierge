import asyncio
import importlib
import logging
import sys
import traceback
from typing import Any
from typing import List
from typing import Literal
from typing import Optional

from fastapi import FastAPI
from fastapi import HTTPException
from fastapi import Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.websockets import WebSocket
from fastapi.websockets import WebSocketDisconnect
from google.genai import types
from pydantic import BaseModel
from pydantic import ValidationError
from uvicorn.main import run as uvicorn_run

from ..agents import Agent
from ..agents import LiveRequest
from ..agents import LiveRequestQueue
from ..artifacts import InMemoryArtifactService
from ..events import Event
from ..runners import Runner
from ..sessions.database_session_service import DatabaseSessionService
from ..sessions.in_memory_session_service import InMemorySessionService
from ..sessions.session import Session
from .utils import envs

logger = logging.getLogger(__name__)


class AgentRunRequest(BaseModel):
  app_name: str
  user_id: str
  session_id: str
  new_message: types.Content
  function_call_event_id: Optional[str] = None


def run_fast_api(
    *,
    app_name: str,
    agent_dir: str,
    agent_name: str,
    session_db_url: str = "",
    allow_origins: Optional[list[str]] = None,
) -> None:
  """Runs the FastAPI server."""
  if agent_dir not in sys.path:
    sys.path.append(agent_dir)

  agent_module = importlib.import_module(agent_name)
  root_agent: Agent = agent_module.agent.root_agent
  envs.load_dotenv_for_agent(agent_name, agent_dir)

  artifact_service = InMemoryArtifactService()
  if not session_db_url:
    session_service = InMemorySessionService()
  else:
    session_service = DatabaseSessionService(db_url=session_db_url)
  app = FastAPI()
  origins = ["http://localhost:4200"]
  app.add_middleware(
      CORSMiddleware,
      allow_origins=origins,
      allow_credentials=True,
      allow_methods=["*"],
      allow_headers=["*"],
  )

  if allow_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allow_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

  runner = Runner(
      app_name=app_name,
      agent=root_agent,
      artifact_service=artifact_service,
      session_service=session_service,
  )

  @app.get(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}",
      response_model_exclude_none=True,
  )
  def get_session(app_name: str, user_id: str, session_id: str) -> Session:
    session = session_service.get_session(app_name, user_id, session_id)
    if not session:
      raise HTTPException(status_code=404, detail="Session not found")
    return session

  @app.get(
      "/apps/{app_name}/users/{user_id}/sessions",
      response_model_exclude_none=True,
  )
  def list_sessions(app_name: str, user_id: str) -> list[str]:
    return session_service.list_sessions(app_name, user_id).session_ids

  @app.post(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}",
      response_model_exclude_none=True,
  )
  def create_session(
      app_name: str,
      user_id: str,
      session_id: str,
      state: Optional[dict[str, Any]] = None,
  ) -> Session:
    if session_service.get_session(app_name, user_id, session_id) is not None:
      logger.warning("Session already exists: %s", session_id)
      raise HTTPException(
          status_code=400, detail=f"Session already exists: {session_id}"
      )

    logger.info("New session created: %s", session_id)
    return session_service.create_session(
        app_name, user_id, state, session_id=session_id
    )

  @app.delete("/apps/{app_name}/users/{user_id}/sessions/{session_id}")
  def delete_session(app_name: str, user_id: str, session_id: str):
    session_service.delete_session(app_name, user_id, session_id)

  @app.get(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}/artifacts/{artifact_name}",
      response_model_exclude_none=True,
  )
  def load_artifact(
      app_name: str,
      user_id: str,
      session_id: str,
      artifact_name: str,
      version: int | None = Query(None),
  ) -> types.Part | None:
    artifact = artifact_service.load_artifact(
        app_name, user_id, session_id, artifact_name, version
    )
    if not artifact:
      raise HTTPException(status_code=404, detail="Artifact not found")
    return artifact

  @app.get(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}/artifacts",
      response_model_exclude_none=True,
  )
  def list_artifact_names(
      app_name: str, user_id: str, session_id: str
  ) -> list[str]:
    return artifact_service.list_artifact_keys(app_name, user_id, session_id)

  @app.get(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}/artifacts/{artifact_name}/versions",
      response_model_exclude_none=True,
  )
  def list_artifact_versions(
      app_name: str, user_id: str, session_id: str, artifact_name: str
  ) -> list[int]:
    return artifact_service.list_versions(
        app_name, user_id, session_id, artifact_name
    )

  @app.delete(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}/artifacts/{artifact_name}",
  )
  def delete_artifact(
      app_name: str, user_id: str, session_id: str, artifact_name: str
  ):
    artifact_service.delete_artifact(
        app_name, user_id, session_id, artifact_name
    )

  @app.post("/agent/run", response_model_exclude_none=True)
  def agent_run(req: AgentRunRequest) -> list[Event]:

    session = session_service.get_session(
        req.app_name, req.user_id, req.session_id
    )
    if not session:
      raise HTTPException(status_code=404, detail="Session not found")

    events = list(
        runner.run(
            session=session,
            new_message=req.new_message,
            function_call_event_id=req.function_call_event_id,
        )
    )
    logger.info("Generated %s events in agent run: %s", len(events), events)
    return events

  @app.post("/agent/run_streaming")
  async def agent_run_sse(req: AgentRunRequest) -> StreamingResponse:
    # SSE endpoint
    session = session_service.get_session(
        req.app_name, req.user_id, req.session_id
    )
    if not session:
      raise HTTPException(status_code=404, detail="Session not found")

    # Convert the events to properly formatted SSE
    async def event_generator():
      try:
        for event in runner.run(
            session=session,
            new_message=req.new_message,
            function_call_event_id=req.function_call_event_id,
        ):
          # Format as SSE data
          sse_event = event.model_dump_json(exclude_none=True)
          logger.info("Generated event in agent run streaming: %s", sse_event)
          yield f"data: {sse_event}\n\n"
      except Exception as e:
        logger.exception("Error in event_generator: %s", e)
        # You might want to yield an error event here
        yield f'data: {{"error": "{str(e)}"}}\n\n'

    # Returns a streaming response with the proper media type for SSE
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
    )

  @app.websocket(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}/run_live"
  )
  async def agent_live_run(
      websocket: WebSocket,
      app_name: str,
      user_id: str,
      session_id: str,
      modalities: List[Literal["TEXT", "AUDIO"]] = Query(
          default=["TEXT", "AUDIO"]
      ),  # Only allows "TEXT" or "AUDIO"
  ) -> None:
    await websocket.accept()
    session = session_service.get_session(app_name, user_id, session_id)
    if not session:
      # Accept first so that the client is aware of connection establishment,
      # then close with a specific code.
      await websocket.close(code=1002, reason="Session not found")
      return

    live_request_queue = LiveRequestQueue()

    async def forward_events():
      async for event in runner.run_live(
          session=session, live_request_queue=live_request_queue
      ):
        await websocket.send_text(event.model_dump_json(exclude_none=True))

    async def process_messages():
      try:
        while True:
          data = await websocket.receive_text()
          # Validate and send the received message to the live queue.
          live_request_queue.send(LiveRequest.model_validate_json(data))
      except ValidationError as ve:
        logger.error("Validation error in process_messages: %s", ve)

    # Run both tasks concurrently and cancel all if one fails.
    tasks = [
        asyncio.create_task(forward_events()),
        asyncio.create_task(process_messages()),
    ]
    done, pending = await asyncio.wait(
        tasks, return_when=asyncio.FIRST_EXCEPTION
    )
    try:
      # This will re-raise any exception from the completed tasks.
      for task in done:
        task.result()
    except WebSocketDisconnect:
      logger.info("Client disconnected during process_messages.")
    except Exception as e:
      logger.exception("Error during live websocket communication: %s", e)
      traceback.print_exc()
    finally:
      for task in pending:
        task.cancel()

  uvicorn_run(app, host="0.0.0.0", log_config=None)
