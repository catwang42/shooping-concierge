import asyncio
import base64
from datetime import datetime
import io
import logging
import mimetypes
import os
import random
import re
import string
import threading
import time
import types

from agents.events import Event
from agents.sessions.session import Session
from google.genai import types as genai_types
from PIL import Image
import streamlit as st
import streamlit.components.v1 as components

from ...agents import LiveRequestQueue
from . import app_context
from . import artifacts_tab
from . import eval_tab
from . import event_dialog
from . import remote_mode

logger = logging.getLogger(__name__)


def show_event_dialog(event_index):
  st.session_state.event_dialog_index = event_index
  event_dialog.show()


# Uses fragment so button clicks won't cause full page rerun.
@st.fragment
def render_avatar(author, event_index, part_index):
  # avatar = '👤' if author == 'user' else '🤖'
  if author == 'user':
    avatar = '👤'
  elif author == 'evaluation':
    avatar = '📝'
  else:
    avatar = '🤖'
  inital = (
      ''.join(x[0] for x in author.split('_'))[:2].upper()
      if author != 'user' and author != 'root_agent'
      else ''
  )
  unique_key = f'avatar_{event_index}_{part_index}_{random.randint(0, 100000)}'

  st.button(
      inital,
      icon=avatar,
      key=unique_key,
      help=author,
      on_click=show_event_dialog,
      args=(event_index,),
  )


# Uses fragment so button clicks won't cause full page rerun.
@st.fragment
def render_function_call_button(event_index, function_calls):
  title = f"⚡ {', '.join([fc.name for fc in function_calls])}"
  with st.popover(title):
    st.button(
        'Details',
        key=f'details_{event_index}_{random.randint(0, 100000)}',
        on_click=show_event_dialog,
        args=(event_index,),
    )
    for fc in function_calls:
      title = f'**{fc.name}**'
      if fc.id:
        title += f' ({fc.id})'
      st.write(title)
      st.write(fc.args)


# Uses fragment so button clicks won't cause full page rerun.
@st.fragment
def render_function_response_button(event_index, function_responses):
  event = st.session_state.session.events[event_index]
  title = f"✔️ {', '.join([fr.name for fr in function_responses])}"
  with st.popover(title):
    st.button(
        'Details',
        key=f'details_{event_index}_{random.randint(0, 100000)}',
        on_click=show_event_dialog,
        args=(event_index,),
    )
    for fr in function_responses:
      title = f'**{fr.name}**'
      if fr.id:
        title += f' ({fr.id})'
      st.write(title)
      st.write(fr.response)
    if event.actions.state_delta:
      st.write('Updated context:')
      st.write(event.actions.state_delta)
    if event.actions.artifact_delta:
      st.write('Updated artifact and version:')
      st.write(event.actions.artifact_delta)


last_fc_container = None
last_fc_author = None


def render_chat_row(author, event_index, part_index):
  cols = st.columns([8, 92], vertical_alignment='top')
  with cols[0]:
    render_avatar(author, event_index, part_index)
  return cols[1]


def render_content(event_index, author, content, actual_tools=[]):
  global last_fc_container
  global last_fc_author
  function_calls = []
  function_responses = []
  for part_index, part in enumerate(content.parts):
    if part.function_call:
      function_calls.append(part.function_call)
    elif part.function_response:
      function_responses.append(part.function_response)
    else:
      last_fc_container = None
      last_fc_author = None
      # Sometime the model returns '\n' and it messes up the UI.
      if part.text and not part.text.strip():
        continue
      chat_container = render_chat_row(author, event_index, part_index)
      with chat_container:
        st.write(transform_part(part))

  if function_calls or function_responses:
    if not last_fc_container or last_fc_author != author:
      last_fc_author = author
      chat_container = render_chat_row(author, event_index, 0)
      with chat_container:
        last_fc_container = st.container(key=f'row_layout_fc_{event_index}_0')

    with last_fc_container:
      if function_calls:
        render_function_call_button(event_index, function_calls)
        actual_tools.extend(function_calls)
      if function_responses:
        render_function_response_button(event_index, function_responses)


def transform_part(part):
  if part.text:
    if part.thought:
      return '\n'.join('> %s' % f for f in part.text.strip().split())
    else:
      return part.text.strip()
  elif part.executable_code:
    return f"""```python
{part.executable_code.code}
```"""
  elif part.code_execution_result:
    return part.code_execution_result
  elif part.inline_data:
    if part.inline_data.mime_type.startswith('image/'):
      return Image.open(io.BytesIO(part.inline_data.data))
    data_str = str(part.inline_data.data)
    return f"""
**mime_type**: `{part.inline_data.mime_type}`

**data**: {data_str if len(data_str) < 200 else data_str[:200] + '...'}
"""


def extract_code_block(text: str):
  """Returns: the first code block in the model message and truncate everything after it."""
  pattern = re.compile(
      (
          r'(?P<prefix>.*?)```(tool_code|python)\n'
          '(?P<code>.*?)\n```(?P<suffix>.*?)$'
      ).encode(),
      re.DOTALL,
  )
  pattern_match = pattern.search(text.encode())
  if pattern_match is None:
    return text, None

  prefix = pattern_match.group('prefix').decode()
  code = pattern_match.group('code').decode()
  return prefix, code


text_column = None
# function calling container that can show multiple function calls


def render_events(index_range):
  global text_column
  session = st.session_state.session

  eval_dataset_index = 0
  actual_tools = []
  for i in index_range:
    event = session.events[i]
    if not event.partial:
      text_column = None

    if not event.partial:
      if event.error_code:
        error_message = f'**{event.error_code}**'
        if event.error_message:
          error_message += f'\n\n{event.error_message}'
        st.error(error_message)
      elif event.content:
        render_content(
            i, event.author, event.content, actual_tools=actual_tools
        )
      else:
        logger.info(
            'Event with no content: %s', event.model_dump(exclude_none=True)
        )

    if event.actions.artifact_delta:
      for key, version in event.actions.artifact_delta.items():
        artifact = app_context.get_artifact_service().load_artifact(
            session.app_name, session.user_id, session.id, key, version
        )
        artifacts_tab.render_artifact(artifact)

    if event.grounding_metadata and event.grounding_metadata.search_entry_point:
      st.markdown(
          event.grounding_metadata.search_entry_point.rendered_content,
          unsafe_allow_html=True,
      )

    eval_dataset_index = eval_tab.load_eval_into_session(
        session, i, eval_dataset_index, actual_tools
    )


# Merges all partial text streams into a single embedded text stream.
def transform_stream(stream):
  # Does not do anything in non-streaming mode.
  if not st.session_state.streaming:
    yield from stream
    return

  non_text_event = None

  def text_stream(event):
    nonlocal non_text_event
    if event.content and event.content.parts:
      yield event.content.parts[0].text
    while True:
      try:
        event = next(stream)
        if event.content and event.content.parts[0].text:
          # Ignores non-partial text because it's already rendered.
          if event.partial:
            yield event.content.parts[0].text
        else:
          non_text_event = event
          break
      except StopIteration:
        break

  while True:
    try:
      event = next(stream)
      if event.content and event.partial:
        yield text_stream(event)
        if non_text_event:
          yield non_text_event
          non_text_event = None
      else:
        yield event
    except StopIteration:
      break


def run_prompt(prompt: str):
  parts = []
  has_files = False
  if st.session_state[st.session_state.file_uploader_key]:
    has_files = True
    uploaded_files = st.session_state[st.session_state.file_uploader_key]
    # Uses a different key to clear the file uploader.
    st.session_state.file_uploader_key = str(time.time())
    for file in uploaded_files:
      mime_type, _ = mimetypes.guess_type(file.name)
      parts.append(
          genai_types.Part(
              inline_data=genai_types.Blob(
                  mime_type=mime_type, data=file.read()
              )
          )
      )
  parts.append(genai_types.Part(text=prompt))
  content = genai_types.Content(role='user', parts=parts)

  run_content(content)
  if has_files:
    # Rerun the page to clear the file uploader.
    st.rerun()


def run_content(content: genai_types.Content):
  session = st.session_state.session
  session_length = len(session.events)
  render_content(session_length, 'user', content)

  events = app_context.get_runner().run(
      session=session,
      new_message=content,
      streaming=st.session_state.streaming
      if st.session_state.streaming
      else None,
  )
  running_container = st.container()
  with st.spinner('Running...'):
    with running_container:
      for event in transform_stream(events):
        event_index = len(session.events) - 1
        if isinstance(event, types.GeneratorType):
          chat_container = render_chat_row('model', event_index, 0)
          with chat_container:
            st.write_stream(event)
        else:
          # Do not render non-partial text, since it's already rendered above.
          if (
              event.content
              and event.content.parts
              and event.content.parts[0].text
              and st.session_state.streaming == 'server-socket'
          ):
            continue
          render_events(
              range(event_index, event_index + 1),
          )

  # Handle get_user_choice tool response
  if session.events:
    function_call_event = session.events[-1]
    for function_call in function_call_event.get_function_calls():
      if function_call.name == 'get_user_choice':
        with st.container(key=f'row_layout_user_choice', border=True):
          for option in function_call.args['options']:
            st.button(option, on_click=run_prompt, args=(option,))


def render_last_event(session: Session):
  if not session.events:
    return
  render_events(range(len(session.events) - 1, len(session.events)))


def run_prompt_remote(prompt: str):
  session: Session = st.session_state.session
  content = genai_types.Content(
      role='user', parts=[genai_types.Part.from_text(text=prompt)]
  )

  characters = string.ascii_letters + string.digits
  invocation_id = ''.join(random.choice(characters) for _ in range(8))
  user_input_event = Event(
      invocation_id=invocation_id, author='user', content=content
  )
  session.events.append(user_input_event)
  render_last_event(session)

  with st.spinner('Running...'):
    remote_events = remote_mode.run(
        session.app_name, session.user_id, session.id, content
    )
    for event in remote_events:
      render_last_event(session)


def rerun_session():
  session = st.session_state.session
  old_events = session.events
  # We only clear the events and event logs, but keep the session context.
  session.events = []
  st.session_state.call_llm_spans = {}
  for event in old_events:
    if event.content and event.author == 'user' and event.content.parts:
      print(f'Rerun session: {event.content.parts[0].text}')
      run_prompt(event.content.parts[0].text)


async def run_live(runner, session, live_request_queue):
  events = runner.run_live(
      session=session,
      live_request_queue=live_request_queue,
  )
  import pyaudio

  pya_interface = pyaudio.PyAudio()
  stream = pya_interface.open(
      format=pyaudio.paInt16,
      channels=1,
      rate=24000,
      output=True,
  )

  try:
    async for event in events:
      event_index = len(session.events) - 1
      # TODO: re-enable chat row rendering
      # if isinstance(event, types.GeneratorType):
      #   chat_container = render_chat_row('model', event_index, 0)
      #   with chat_container:
      #     st.write_stream(event)
      # else:
      #   # Do not render non-partial text, since it's already rendered above.
      #   if (
      #       event.content
      #       and event.content.parts
      #       and event.content.parts[0].text
      #       and st.session_state.streaming == 'server-socket'
      #   ):
      #     continue
      # Handle audio data
      inline_data = (
          event.content
          and event.content.parts
          and event.content.parts[0].inline_data
      )
      if inline_data and inline_data.mime_type.startswith('audio/pcm'):
        stream.write(inline_data.data)
        continue
      # TODO: re-enable chat row rendering
      # render_events(
      #     range(event_index, event_index + 1),
      # )
      await asyncio.sleep(0)
  finally:
    stream.stop_stream()
    stream.close()
    pya_interface.terminate()


def streaming_worker(runner, session, live_request_queue):
  # Create a new event loop for this thread.
  loop = asyncio.new_event_loop()
  asyncio.set_event_loop(loop)

  loop.run_until_complete(run_live(runner, session, live_request_queue))
  # Keep the event loop running to process incoming audio frames.
  loop.run_forever()


def render_chat():
  logger.info('render_chat...')

  # Initialize the saved audio buffer if it does not exist
  if 'saved_audio' not in st.session_state:
    st.session_state['saved_audio'] = b''

  if 'live_request_queue' not in st.session_state:
    st.session_state.live_request_queue = LiveRequestQueue()

  if not st.session_state.demo_name:
    return

  if app_context.is_remote_mode():
    _render_chat_remote()
    return

  session: Session = st.session_state.session
  root_agent = app_context.get_root_agent()
  session.state['_time'] = str(datetime.now())
  if not session.events and root_agent.greeting_prompt:
    # new_message=None triggers the greeting prompt.
    events = list(
        app_context.get_runner().run(
            session=session,
            new_message=None,
            streaming=st.session_state.streaming
            if st.session_state.streaming
            else None,
        )
    )

  if st.session_state.streaming != 'bidi':
    if session.events:
      render_events(range(len(session.events)))
    elif root_agent.description:
      with st.container(border=True):
        st.write(root_agent.description)

  # Check if streaming mode is set to 'server-socket-audio'
  if st.session_state.streaming == 'bidi':
    if st.session_state.is_live:
      parent_dir = os.path.dirname(os.path.abspath(__file__))
      media_streamer_path = os.path.join(parent_dir, '../media_streamer')
      media_streamer = components.declare_component(
          'media_streamer',
          path=media_streamer_path,
      )

      st.markdown('---')
      st.subheader('Gemini Bidi Live')
      st.write(
          'Press the button to start/stop streaming. Audio chunks will be'
          ' sent from the browser.'
      )

      media_data = media_streamer(
          key='media_streamer', some_prop='initial value'
      )

      if 'media_worker' not in st.session_state:
        runner = app_context.get_runner()
        session = st.session_state.session
        worker_thread = threading.Thread(
            target=streaming_worker,
            args=(
                runner,
                session,
                st.session_state.live_request_queue,
            ),
            daemon=True,
        )
        worker_thread.start()

        # Store the worker thread in session state.
        st.session_state['media_worker'] = worker_thread
        # time.sleep(2)
      else:
        # The worker is already running.
        if 'videoFrame' in media_data:
          # video data is in the following format: data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABA
          base64_str = media_data['videoFrame'].split('base64,')[1]
          decoded_image = base64.b64decode(base64_str)
          # video is sent as images
          st.session_state.live_request_queue.send_realtime(
              genai_types.Blob(data=decoded_image, mime_type='image/jpeg')
          )
        if 'audioChunk' in media_data:
          # audio data is in the following format: data:application/octet-stream;base64,CgAJAAoA
          chunk_data = media_data['audioChunk'].split('base64,', 1)[1]
          # Add missing padding if necessary
          missing_padding = len(chunk_data) % 4
          if missing_padding:
            chunk_data += '=' * (4 - missing_padding)
          decoded = base64.b64decode(chunk_data)
          st.session_state.live_request_queue.send_realtime(
              genai_types.Blob(data=decoded, mime_type='audio/pcm')
          )
  else:
    # Chat input for prompt
    prompt = st.chat_input('Say something')
    if prompt:
      parts = []

      # # TODO: enable this after we fully support audio
      # # Allows users to record/upload audio(non-streaming) to chat
      # audio_file_path = 'user_audio_streaming.wav'
      # if os.path.exists(audio_file_path):
      #   st.success('Audio file found and added to the prompt.')
      #   with open(audio_file_path, 'rb') as audio_file:
      #     audio_part = genai_types.Part.from_bytes(
      #         data=audio_file.read(),
      #         mime_type='audio/wav',
      #     )
      #     parts.append(audio_part)

      # # Add the user-entered prompt
      # parts.append(genai_types.Part(text=prompt))
      # content = genai_types.Content(role='user', parts=parts)

      # # Run content
      # run_content(content)
      run_prompt(prompt)


def _render_chat_remote():
  session: Session = st.session_state.session
  if session.events:
    render_events(range(len(session.events)))
  prompt = st.chat_input('Say something')
  if prompt:
    run_prompt_remote(prompt)
