import streamlit.components.v1 as components

media_streamer = components.declare_component(
    name='media_streamer', path='./media_streamer'
)
