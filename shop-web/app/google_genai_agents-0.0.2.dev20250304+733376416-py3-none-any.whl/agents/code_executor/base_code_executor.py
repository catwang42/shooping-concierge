import abc
import base64

from google.genai import types
from pydantic import BaseModel

from ..agents.invocation_context import InvocationContext
from .code_execution_utils import CodeExecutionInput
from .code_execution_utils import CodeExecutionResult
from .code_execution_utils import File


class BaseCodeExecutor(BaseModel):
  """Base class for all code executors."""

  optimize_data_file: bool = False
  """
  If true, extract and process data files from the model request
  and attach them to the code executor.
  Supported data file MimeTypes are [text/csv].

  Default to False.
  """

  stateful: bool = False
  """
  Whether the code executor is stateful. Default to False.
  """

  error_retry_attempts: int = 2
  """
  The number of attempts to retry on consecutive code execution errors. Default to 2.
  """

  @abc.abstractmethod
  def execute_code(
      self,
      invocation_context: InvocationContext,
      code_execution_input: CodeExecutionInput,
  ) -> CodeExecutionResult:
    """Executes code and return the result."""
    pass

  def _save_output_files(
      self, invocation_context: InvocationContext, output_files: list[File]
  ):
    """Saves the output files to Artifact Service."""
    if invocation_context.artifact_service is None:
      raise ValueError("Artifact service is not initialized.")
    for output_file in output_files:
      invocation_context.artifact_service.save_artifact(
          app_name=invocation_context.app_name,
          user_id=invocation_context.user_id,
          session_id=invocation_context.session.id,
          filename=output_file.name,
          artifact=types.Part.from_bytes(
              data=base64.b64decode(output_file.content),
              mime_type=output_file.mime_type,
          ),
      )
