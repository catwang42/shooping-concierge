"""Utility functions for code execution."""

import base64
import binascii
import copy
import dataclasses
import re

from google.genai import types


@dataclasses.dataclass(frozen=True)
class File:
  """A structure that contains a file name and its content."""

  name: str
  """
  The name of the file with file extension (e.g., "file.csv").
  """

  content: str
  """
  The base64-encoded bytes of the file content.
  """

  mime_type: str = 'text/plain'
  """
  The mime type of the file (e.g., "image/png").
  """


@dataclasses.dataclass
class CodeExecutionInput:
  """A structure that contains the input of code execution."""

  code: str
  """
  The code to execute.
  """

  input_files: list[File] = dataclasses.field(default_factory=list)
  """
  The input files available to the code.
  """

  execution_id: str | None = None
  """
  The execution ID for the stateful code execution.
  """


@dataclasses.dataclass
class CodeExecutionResult:
  """A structure that contains the result of code execution."""

  stdout: str = ''
  """
  The standard output of the code execution.
  """

  stderr: str = ''
  """
  The standard error of the code execution.
  """

  output_artifacts: list[str] = dataclasses.field(default_factory=list)
  """
  The output artifact names from the code execution.
  """


class CodeExecutionUtils:
  """Utility functions for code execution."""

  @staticmethod
  def get_encoded_file_content(data: bytes) -> bytes:
    """Returns the file content as a base64-encoded bytes."""

    def _is_base64_encoded(data: bytes) -> bool:
      try:
        return base64.b64encode(base64.b64decode(data)) == data
      except binascii.Error:
        return False

    return data if _is_base64_encoded(data) else base64.b64encode(data)

  @staticmethod
  def extract_code_and_truncate_content(content: types.Content) -> str | None:
    """Returns the first code block and truncate everything after it."""
    if not content or not content.parts:
      return

    text_parts = [p for p in content.parts if p.text]
    if not text_parts:
      return

    first_text_part = copy.deepcopy(text_parts[0])
    response_text = '\n'.join([p.text for p in text_parts])
    pattern = re.compile(
        (
            r'(?P<prefix>.*?)```(tool_code|python)\n'
            '(?P<code>.*?)\n```(?P<suffix>.*?)$'
        ).encode(),
        re.DOTALL,
    )
    pattern_match = pattern.search(response_text.encode())
    if pattern_match is None:
      return

    code_str = pattern_match.group('code').decode()
    if not code_str:
      return

    content.parts = []
    if pattern_match.group('prefix'):
      first_text_part.text = pattern_match.group('prefix').decode()
      content.parts.append(first_text_part)
    content.parts.append(
        CodeExecutionUtils.build_executable_code_part(code_str)
    )
    return pattern_match.group('code').decode()

  @staticmethod
  def build_executable_code_part(code: str) -> types.Part:
    """Returns the code part."""
    return types.Part.from_executable_code(
        code=code,
        language='PYTHON',
    )

  @staticmethod
  def build_code_execution_result_part(
      code_execution_result: CodeExecutionResult,
  ) -> types.Part:
    """Returns the code execution result part."""
    if code_execution_result.stderr:
      return types.Part.from_code_execution_result(
          outcome='OUTCOME_FAILED',
          output=code_execution_result.stderr,
      )
    final_result = []
    if (
        code_execution_result.stdout
        or not code_execution_result.output_artifacts
    ):
      final_result.append(
          'Code execution result:\n'
          + '```tool_outputs\n%s\n```' % code_execution_result.stdout
      )
    if code_execution_result.output_artifacts:
      final_result.append(
          'Saved artifacts:\n'
          + ','.join(
              ['`%s`' % f for f in code_execution_result.output_artifacts]
          )
      )
    return types.Part.from_code_execution_result(
        outcome='OUTCOME_OK',
        output='\n\n'.join(final_result),
    )

  @staticmethod
  def convert_code_execution_parts(content: types.Content):
    """Converts the code execution parts to text parts."""
    if not content.parts:
      return

    if content.parts[-1].executable_code:
      content.parts[-1] = types.Part(
          text='```tool_code\n%s\n```' % content.parts[-1].executable_code.code,
      )
    elif len(content.parts) == 1 and content.parts[-1].code_execution_result:
      content.parts[-1] = types.Part(
          text=content.parts[-1].code_execution_result.output,
      )
      content.role = 'user'
