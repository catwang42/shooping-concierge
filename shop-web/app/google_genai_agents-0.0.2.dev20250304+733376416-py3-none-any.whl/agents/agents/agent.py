from __future__ import annotations

from functools import cached_property
import logging
from typing import Any
from typing import AsyncGenerator
from typing import Callable
from typing import Generator
from typing import Literal
from typing import Tuple

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import field_validator
from typing_extensions import override

from ..code_executor.base_code_executor import BaseCodeExecutor
from ..events import Event
from ..examples import BaseExampleProvider
from ..examples import Example
from ..flows.base_flow import BaseFlow
from ..flows.registry import FlowRegistry
from ..models import BaseLlm
from ..models import LlmRequest
from ..models import LlmResponse
from ..planner.base_planner import BasePlanner
from ..telemetry import tracer
from ..tools import BaseTool
from ..tools import ToolContext
from .base_agent import BaseAgent
from .callback_context import CallbackContext
from .invocation_context import InvocationContext
from .readonly_context import ReadonlyContext

__all__ = [
    'Agent',
    'BeforeAgentCallback',
    'AfterAgentCallback',
    'BeforeToolCallback',
    'AfterToolCallback',
    'BeforeModelCallback',
    'AfterModelCallback',
    'InstructionProvider',
    'ExamplesUnion',
    'FlowCallable',
]


logger = logging.getLogger(__name__)


BeforeModelCallback = Callable[
    [CallbackContext, LlmRequest], LlmResponse | None
]
AfterModelCallback = Callable[
    [CallbackContext, LlmResponse],
    LlmResponse | None,
]
BeforeAgentCallback = Callable[[CallbackContext], types.Content | None]
AfterAgentCallback = Callable[[CallbackContext], types.Content | None]
BeforeToolCallback = Callable[
    [BaseTool, dict[str, Any], ToolContext],
    dict | None,
]
AfterToolCallback = Callable[
    [BaseTool, dict[str, Any], ToolContext, dict],
    dict | None,
]
InstructionProvider = Callable[[ReadonlyContext], str]

ToolUnion = Callable | BaseTool

ExamplesUnion = list[Example] | BaseExampleProvider

FlowCallable = Callable[[InvocationContext], Generator[Event, None, None]]


class DelegateFlow(BaseFlow):

  _delegate: FlowCallable

  def __init__(self, delegate: FlowCallable) -> None:
    self._delegate = delegate

  def __call__(
      self, invocation_context: InvocationContext
  ) -> Generator[Event, None, None]:
    yield from self._delegate(invocation_context)

  async def run_async(
      self, invocation_context: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    for event in self._delegate(invocation_context):
      yield event


class Agent(BaseAgent):
  """The LLM-based agent."""

  model_config = ConfigDict(
      arbitrary_types_allowed=True,
      extra='forbid',
  )

  model: str | BaseLlm = ''
  """The model to use for the agent.

  When not set, the agent will inherit the model from its parent agent.
  """

  instruction: str | InstructionProvider = ''
  """Instructions for the LLM model, guiding the agent's behavior."""

  global_instruction: str | InstructionProvider = ''
  """Instructions for all the children agents in the entire agent tree.
  Only allowd in root agent.
  You can use this instruction to set up a stable identify or personality across all child agents."""

  flow: str | BaseFlow | FlowCallable = 'auto'
  children: list[BaseAgent] = []
  tools: list[ToolUnion] = []
  generate_content_config: types.GenerateContentConfig | None = None
  examples: ExamplesUnion | None = None
  greeting_prompt: str | None = None

  planning: BasePlanner | bool = False
  """If set, instruct the agent to make a plan and execute it step by step.
  When set to True, the default planner PlanReActPlanner will be used.
  Default to False.
  """

  code_executor: BaseCodeExecutor | None = None
  """If set, allow the agent to execute code blocks from model responses and
  incorporate the execution results into its final response.
  Default to None.
  """

  disable_sibling_agent_transfer: bool = False
  """If true, the agent will not be able to transfer the question to its sibling
  agents. Default to false.
  """

  input_schema: type[BaseModel] | None = None
  output_schema: type[BaseModel] | None = None
  output_key: str | None = None
  """If set, the output of the agent will be stored in the state under this key.
  """

  include_contents: Literal['default', 'none'] | None = None
  """Control the contents to include in the model request.

  'default': All contents are included.
  'none': No contents are included.
  """

  before_model_callback: BeforeModelCallback | None = None
  """Called before the model is called.

  The returned response will be returned to user and the actual model call will
  be skipped.

  Args:
    callback_context: CallbackContext
    llm_request: LlmRequest, The raw model request. Callback can mutate the request.
"""

  after_model_callback: AfterModelCallback | None = None
  """Called after the model is called.

  The returned response takes precedence over the model response.

  Args:
    callback_context: CallbackContext,
    llm_response: LlmResponse, the actual model response.
  """

  before_agent_callback: BeforeAgentCallback | None = None
  """Called before the agent is called.

  If the returned content is not None, it will be added to the session and the
  agent will not be called.

  Args:
    callback_context: CallbackContext,

  Returns:
    The content to return to the user.
  """

  after_agent_callback: AfterAgentCallback | None = None
  """Called after the agent is called.

  If the returned content is not None, it will be added to the session.

  Args:
    callback_context: CallbackContext,
  """

  before_tool_callback: BeforeToolCallback | None = None
  """Called before the tool is called.

  If you return an object, that object will be used as the tool response.
  Otherwise, the tool will be called.

  Args:
    tool: The tool to be called.
    args: The arguments to the tool.
    tool_context: ToolContext,

  Returns:
    The tool response event or None to let the framework call the tool.
  """

  after_tool_callback: AfterToolCallback | None = None
  """Called after the tool is called.

  If you return an object, that object will be used as the tool response.
  Otherwise, the tool will be called.

  Args:
    tool: The tool to be called.
    args: The arguments to the tool.
    tool_context: ToolContext,
    tool_response: The response from the tool.

  Returns:
    None
  """

  @field_validator('name', mode='after')
  @classmethod
  def validate_agent(cls, name: str) -> Any:
    if not name.isidentifier():
      raise ValueError(f'Agent name `{name}` is invalid.')
    return name

  @field_validator('generate_content_config', mode='after')
  @classmethod
  def validate_generate_content_config(
      cls, generate_content_config: types.GenerateContentConfig
  ) -> types.GenerateContentConfig:
    if not generate_content_config:
      return types.GenerateContentConfig()
    if generate_content_config.tools:
      raise ValueError('All tools must be set via Agent.tools.')
    if generate_content_config.system_instruction:
      raise ValueError('System instruction must be set via Agent.instruction.')
    if generate_content_config.response_schema:
      raise ValueError('Response schema must be set via Agent.output_schema.')
    return generate_content_config

  # Get the model name from the agent or its parent agent.
  def get_model(self):
    agent = self
    while agent:
      if agent.model:
        return agent.model
      agent = agent.parent_agent
    raise ValueError(f'No model found for agent {self.name}.')

  def find_child(self, name: str) -> BaseAgent | None:
    """Finds the child agent with the given name recursively."""
    for child in self.children:
      if child.name == name:
        return child
      # Other agent types do not have children.
      if isinstance(child, Agent):
        result = child.find_child(name)
        if result:
          return result
    return None

  def find_agent(self, name: str) -> BaseAgent | None:
    """Similar to find_child, but also check itself."""
    if self.name == name:
      return self
    return self.find_child(name)

  def model_post_init(self, __context):
    for child in self.children:
      if child.parent_agent:
        logger.error(
            'Agent %s already has a parent agent %s.',
            child.name,
            child.parent_agent.name,
        )
        raise ValueError(
            f'Agent {child.name} already has a parent agent'
            f' {child.parent_agent.name}.'
        )
      child.parent_agent = self

  def _handle_output_key(self, event, output_key, output_schema):
    """Processes the final response of an event and updates the state delta."""
    if (
        output_key
        and event.is_final_response()
        and event.content
        and event.content.parts
    ):
      result = event.content.parts[0].text
      if output_schema:
        result = output_schema.model_validate_json(result).model_dump(
            exclude_none=True
        )
      event.actions.state_delta[output_key] = result

  async def run_live(
      self,
      parent_context: InvocationContext,
  ) -> AsyncGenerator[Event, None]:
    with tracer.start_as_current_span(f'call_agent [{self.name}]'):
      # Always creates a new invocation context for the current agent.
      invocation_context = parent_context.model_copy(update={'agent': self})

      async for event in self.__resolved_flow.call_live(invocation_context):
        self._handle_output_key(event, self.output_key, self.output_schema)
        yield event
      if invocation_context.end_invocation:
        return

  def run(
      self,
      parent_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    with tracer.start_as_current_span(f'call_agent [{self.name}]'):
      # Always creates a new invocation context for the current agent.
      invocation_context = parent_context.model_copy(update={'agent': self})
      self._amend_branch(invocation_context)

      # Run before_agent_callback if it exists.
      event, end_invocation = self._handle_before_agent_callback(
          invocation_context
      )
      if event:
        yield event
      if end_invocation:
        return

      # Run the flow.
      events = self.__resolved_flow(invocation_context)
      for event in events:
        self._handle_output_key(event, self.output_key, self.output_schema)
        yield event
      if invocation_context.end_invocation:
        return

      # Run after_agent_callback if it exists.
      event = self._handle_after_agent_callback(invocation_context)
      if event:
        yield event

  @override
  async def run_async(
      self, parent_context: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    invocation_context = parent_context.model_copy(update={'agent': self})
    self._amend_branch(invocation_context)

    # Run before_agent_callback if it exists.
    event, end_invocation = self._handle_before_agent_callback(
        invocation_context
    )
    if event:
      yield event
    if end_invocation:
      return

    # Run the flow.
    async for event in self.__resolved_flow.run_async(invocation_context):
      self._handle_output_key(event, self.output_key, self.output_schema)
      yield event
    if invocation_context.end_invocation:
      return

    # Run after_agent_callback if it exists.
    event = self._handle_after_agent_callback(invocation_context)
    if event:
      yield event

  @cached_property
  def children_dict(self) -> dict[str, BaseAgent]:
    """Returns a dict of children agents keyed by their names."""
    return {agent.name: agent for agent in self.children}

  @cached_property
  def resolved_model(self) -> str | BaseLlm:
    current_agent = self
    while current_agent:
      if current_agent.model:
        return current_agent.model
      current_agent = current_agent.parent_agent
    raise ValueError(f'No model found for agent {self.name}.')

  @cached_property
  def __resolved_flow(self) -> BaseFlow:
    if isinstance(self.flow, str):
      return FlowRegistry.new_flow(self.flow)
    if isinstance(self.flow, BaseFlow):
      return self.flow
    if isinstance(self.flow, Callable):
      return DelegateFlow(self.flow)
    raise ValueError(f'Unsupported flow type: {type(self.flow)}')

  def _amend_branch(self, invocation_context: InvocationContext):
    # TODO(weisun): remove consolidate branch change into one place.
    from ..flows.parallel_flow import ParallelFlow

    if not isinstance(self.__resolved_flow, ParallelFlow):
      invocation_context.branch = (
          invocation_context.branch + '.' + self.name
          if invocation_context.branch
          else None
      )

  def _handle_before_agent_callback(
      self, invocation_context: InvocationContext
  ) -> Tuple[Event | None, bool]:
    """Runs the before_agent_callback if it exists.

    Returns:
      tuple: A tuple containing:
        - Event | None: an event if callback provides content or changed state.
        - bool: a flag indicating whether to end the invocation.
    """
    ret_event = None
    ret_end_invocation = False

    if not isinstance(self.before_agent_callback, Callable):
      return ret_event, ret_end_invocation

    callback_context = CallbackContext(invocation_context)
    before_agent_callback_content = self.before_agent_callback(callback_context)

    if before_agent_callback_content:
      ret_event = Event(
          invocation_id=invocation_context.invocation_id,
          author=self.name,
          branch=invocation_context.branch,
          content=before_agent_callback_content,
          actions=callback_context._event_actions,
      )
      ret_end_invocation = True
      return ret_event, ret_end_invocation

    if callback_context.state.has_delta():
      ret_event = Event(
          invocation_id=invocation_context.invocation_id,
          author=self.name,
          branch=invocation_context.branch,
          actions=callback_context._event_actions,
      )
    if invocation_context.end_invocation:
      ret_end_invocation = True

    return ret_event, ret_end_invocation

  def _handle_after_agent_callback(
      self, invocation_context: InvocationContext
  ) -> Event | None:
    """Runs the after_agent_callback if it exists.

    Returns:
      Event | None: an event if callback provides content or changed state.
    """
    ret_event = None

    if not isinstance(self.after_agent_callback, Callable):
      return ret_event

    callback_context = CallbackContext(invocation_context)
    after_agent_callback_content = self.after_agent_callback(callback_context)

    if after_agent_callback_content or callback_context.state.has_delta():
      ret_event = Event(
          invocation_id=invocation_context.invocation_id,
          author=self.name,
          branch=invocation_context.branch,
          content=after_agent_callback_content,
          actions=callback_context._event_actions,
      )

    return ret_event
