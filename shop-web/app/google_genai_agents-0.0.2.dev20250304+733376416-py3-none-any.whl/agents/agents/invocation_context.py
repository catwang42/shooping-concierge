from typing import Literal
from typing import TypeAlias

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict

from ..artifacts.base_artifact_service import BaseArtifactService
from ..memory.base_memory_service import BaseMemoryService
from ..sessions.base_session_service import BaseSessionService
from ..sessions.session import Session
from .base_agent import BaseAgent
from .live_request_queue import LiveRequestQueue

StreamingMode: TypeAlias = Literal[None, 'server-socket', 'bidi']


class InvocationContext(BaseModel):
  """An invocation context represents the data of a single invocation of an agent.

  An invocation:
    1. Starts with a user message and ends with a final response.
    2. Can contain one or multiple agent calls.
    3. Is handled by runner.run().

  An invocation runs an agent until it does not request to transfer to another
  agent.

  An agent call:
    1. Is handled by agent.run().
    2. Ends when agent.run() ends.

  An LLM agent call is an agent with a BaseLLMFlow.
  An LLM agent call can contain one or multiple steps.
  An LLM agent runs steps in a loop until:
    1. A final response is generated.
    2. The agent transfers to another agent.
    3. The end_invocation is set to true by any callbacks or tools.

  A step:
    1. Calls the LLM only once and yields its response.
    2. Calls the tools and yields their responses if requested.
  The summarization of the function response is considered another step, since
  it is another llm call.
  A step ends when it's done calling llm and tools, or if the end_invocation
  is set to true at any time.

  ```
  ┌─────────────────────── invocation ──────────────────────────┐
  ┌──────────── llm_agent_call_1 ────────────┐ ┌─ agent_call_2 ─┐
  ┌──── step_1 ────────┐ ┌───── step_2 ──────┐
  [call_llm] [call_tool] [call_llm] [transfer]
  ```
  """

  model_config = ConfigDict(
      arbitrary_types_allowed=True,
      extra='forbid',
  )

  artifact_service: BaseArtifactService | None = None
  session_service: BaseSessionService
  memory_service: BaseMemoryService | None = None

  invocation_id: str
  """The id of this invocation context. Readonly."""
  branch: str | None = None
  """The branch of the invocation context.

  The format is like agent_1.agent_2.agent_3, where agent_1 is the parent of
  agent_2, and agent_2 is the parent of agent_3.

  Branch is used when multiple child agent shouldn't see their siblings'
  conversaction history.
  """
  agent: BaseAgent
  """The current agent of this invocation context. Readonly."""
  user_content: types.Content | None = None
  """The user content that started this invocation. Readonly."""
  session: Session
  """The current session of this invocation context. Readonly."""
  streaming: StreamingMode = None
  """Streaming mode, None or 'server-socket'."""

  end_invocation: bool = False
  """Whether to end this invocation.

  Set to True in callbacks or tools to terminate this invocation."""

  live_request_queue: LiveRequestQueue | None = None
  """The queue to receive live requests."""

  response_modalities: list[str] | None = None
  """The output modalities of this invocation."""

  @property
  def app_name(self) -> str:
    return self.session.app_name

  @property
  def user_id(self) -> str:
    return self.session.user_id
