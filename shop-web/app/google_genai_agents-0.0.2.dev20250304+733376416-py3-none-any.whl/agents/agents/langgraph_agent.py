from typing import AsyncGenerator
from typing import Callable
from typing import Generator

from google.genai import types
from langchain_core.messages import AIMessage
from langchain_core.messages import HumanMessage
from langgraph.graph.graph import CompiledGraph
from pydantic import ConfigDict
from typing_extensions import override

from ..events import Event
from ..flows.base_flow import BaseFlow
from .base_agent import BaseAgent
from .invocation_context import InvocationContext

FlowCallable = Callable[[InvocationContext], Generator[Event, None, None]]


class LangGraphAgent(BaseAgent):
  """Currently just a concept implementation, only supports single turn."""

  model_config = ConfigDict(
      arbitrary_types_allowed=True,
  )

  graph: CompiledGraph

  def run(
      self,
      parent_context: InvocationContext,
  ) -> Generator[Event, None, None]:

    messages = self._get_messages(parent_context.session.events)

    # Needed for langgraph checkpointer (for subsequent invocations; multi-turn)
    config = {'configurable': {'thread_id': parent_context.session.id}}
    # Use the Runnable
    final_state = self.graph.invoke({'messages': messages}, config)
    result = final_state['messages'][-1].content

    result_event = Event(
        invocation_id=parent_context.invocation_id,
        author=self.name,
        content=types.Content(
            role='model',
            parts=[types.Part.from_text(text=result)],
        ),
    )
    yield result_event

  def _get_messages(
      self, events: list[Event]
  ) -> list[HumanMessage | AIMessage]:
    """Extracts messages from given list of events.

    If the developer provides their own memory within langgraph, we return the
    last user messages only. Otherwise, we return all messages between the user
    and the agent.

    Args:
      events: the list of events

    Returns:
      list of messages
    """
    if self.graph.checkpointer:
      return LangGraphAgent._get_last_human_messages(events)
    else:
      return self._get_conversation_with_agent(events)

  @staticmethod
  def _get_last_human_messages(events: list[Event]) -> list[HumanMessage]:
    """Extracts last human messages from given list of events.

    Args:
      events: the list of events

    Returns:
      list of last human messages
    """
    messages = []
    for event in reversed(events):
      if messages and event.author != 'user':
        break
      if event.author == 'user' and event.content and event.content.parts:
        messages.append(HumanMessage(content=event.content.parts[0].text))
    return list(reversed(messages))

  def _get_conversation_with_agent(
      self, events: list[Event]
  ) -> list[HumanMessage | AIMessage]:
    """Extracts messages from given list of events.

    Args:
      events: the list of events

    Returns:
      list of messages
    """

    messages = []
    for event in events:
      if not event.content or not event.content.parts:
        continue
      if event.author == 'user':
        messages.append(HumanMessage(content=event.content.parts[0].text))
      elif event.author == self.name:
        messages.append(AIMessage(content=event.content.parts[0].text))
    return messages

  @override
  async def run_async(
      self, parent_context: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    raise NotImplementedError('Not Implemented yet.')
