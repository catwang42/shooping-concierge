import json
from typing import AsyncGenerator
from typing import Generator

import requests
from typing_extensions import override

from ..events import Event
from .base_agent import BaseAgent
from .invocation_context import InvocationContext


class RemoteAgent(BaseAgent):
  url: str

  def run(
      self,
      parent_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    data = {
        'invocation_id': parent_context.invocation_id,
        'session': parent_context.session.model_dump(exclude_none=True),
    }
    events = requests.post(self.url, data=json.dumps(data))
    events.raise_for_status()
    for event in events.json():
      e = Event.model_validate(event)
      e.author = self.name
      yield e

  @override
  async def run_async(
      self, parent_context: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    raise NotImplementedError('Not Implemented yet.')
