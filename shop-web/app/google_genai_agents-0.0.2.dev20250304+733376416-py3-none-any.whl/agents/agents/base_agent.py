from __future__ import annotations

from abc import abstractmethod
import typing
from typing import AsyncGenerator
from typing import Generator

from pydantic import BaseModel
from pydantic import Field

if typing.TYPE_CHECKING:
  from ..events import Event
  from .invocation_context import InvocationContext


class BaseAgent(BaseModel):
  """Base class for all agents."""

  name: str
  """The agent's name.

  Agent name must be a unique Python identifier within the agent tree.
  """

  description: str = ''
  """One line description about the agent's capability.

  The model uses this to determine whether to delegate control to the agent.
  """

  parent_agent: BaseAgent | None = Field(default=None, init=False)
  """The parent agent in the agent tree.

  Note that one agent cannot be added to two agents' children list.
  """

  @abstractmethod
  def run(
      self,
      parent_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    pass

  async def run_live(
      self,
      parent_context: InvocationContext,
  ) -> AsyncGenerator[Event, None]:
    ...

  @abstractmethod
  async def run_async(
      self, parent_context: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    ...

  def get_root_agent(self) -> BaseAgent:
    """Get the root agent of the current agent."""
    root_agent = self
    while root_agent.parent_agent is not None:
      root_agent = root_agent.parent_agent
    return root_agent
