from __future__ import annotations

from typing import TYPE_CHECKING

from google.genai import types

from . import _automatic_function_calling_util
from .function_tool import FunctionTool

if TYPE_CHECKING:
  from crewai_tools.tools.base_tool import BaseTool as CrewaiBaseTool


class CrewaiTool(FunctionTool):
  """Use this class to wrap a CrewAI tool.

  If the original tool name and description are not suitable, you can override
  them in the constructor.
  """

  tool: CrewaiBaseTool

  def __init__(self, tool: CrewaiBaseTool, *, name: str, description: str):
    super().__init__(tool.run)
    self.tool = tool
    if name:
      self.name = name
    elif tool.name:
      # Right now, CrewAI tool name contains white spaces. White spaces are
      # not supported in our framework. So we replace them with "_".
      self.name = tool.name.replace(" ", "_").lower()
    if description:
      self.description = description
    elif tool.description:
      self.description = tool.description

  def get_declaration(self) -> types.FunctionDeclaration:
    """Build the function declaration for the tool."""
    function_declaration = _automatic_function_calling_util.build_function_declaration_for_params_for_crewai(
        False,
        self.name,
        self.description,
        self.func,
        self.tool.args_schema.model_json_schema(),
    )
    return function_declaration
