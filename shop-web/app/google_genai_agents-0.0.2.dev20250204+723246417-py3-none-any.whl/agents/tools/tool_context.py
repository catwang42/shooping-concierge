from __future__ import annotations

import typing

from google.genai import types

if typing.TYPE_CHECKING:
  from ..agents.invocation_context import InvocationContext


class ToolContext:

  def __init__(
      self,
      invocation_context: InvocationContext,
      function_call_event_id: str | None = None,
      function_call_id: str | None = None,
  ):
    from ..events.event_actions import EventActions
    from ..sessions.state import State

    self.actions = EventActions()
    self._invocation_context = invocation_context
    self._session = invocation_context.session
    self.state = State(
        value=self._session.state, delta=self.actions.state_delta
    )
    self.function_call_event_id = function_call_event_id
    self.function_call_id = function_call_id

  def load_artifact(self, key: str) -> types.Part | None:
    return self._invocation_context.artifact_service.load(self._session.id, key)

  def save_artifact(self, key: str, value: types.Part):
    version = self._invocation_context.artifact_service.save(
        self._session.id, key, value
    )
    self.actions.artifact_delta[key] = version

  def list_artifacts(self) -> list[str]:
    return self._invocation_context.artifact_service.list_keys(self._session.id)
