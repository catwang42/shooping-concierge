import abc
from typing import Any
from typing import TYPE_CHECKING

from google.genai import types

from .tool_context import ToolContext

if TYPE_CHECKING:
  from ..models.llm_request import LlmRequest


# We use regular class instead of Pydantic to have better control on computed
# properties.
class BaseTool:
  """Base class for all tools."""

  def __init__(self, type: str, name: str, description: str):
    self.name = name
    self.type = type
    self.description = description

  @abc.abstractmethod
  def get_declaration(self) -> types.FunctionDeclaration:
    pass

  def process_llm_request(
      self, tool_context: ToolContext, llm_request: 'LlmRequest'
  ):
    pass

  @abc.abstractmethod
  def call(self, *, args: dict[str, Any], tool_context: 'ToolContext') -> Any:
    """Call the tool."""
    pass
