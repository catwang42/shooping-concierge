from typing import Any

import os

from google.genai import types
from pydantic import model_validator

from ..agents.agent import Agent
from ..runners import InMemoryRunner
from . import _automatic_function_calling_util
from .base_tool import BaseTool
from .tool_context import ToolContext


class AgentTool(BaseTool):

  def __init__(self, agent: Agent):
    self.agent = agent
    self.skip_summarization: bool = False
    """Whether to skip summarization of the agent output."""

    super().__init__('agent', agent.name, agent.description)

  @model_validator(mode='before')
  @classmethod
  def populate_name(cls, data: Any) -> Any:
    data['name'] = data['agent'].name
    return data

  def get_declaration(self) -> types.FunctionDeclaration:
    use_vertexai = os.environ.get('GOOGLE_GENAI_USE_VERTEXAI', 0)
    if self.agent.input_schema:
      result = _automatic_function_calling_util.build_function_declaration(
          func=self.agent.input_schema,
          variant='VERTEX_AI' if use_vertexai else 'GOOGLE_AI',
      )
    else:
      result = types.FunctionDeclaration(
          parameters=types.Schema(
              type='OBJECT',
              properties={
                  'request': types.Schema(
                      type='STRING',
                  ),
              },
              required=['request'],
          ),
          description=self.agent.description,
          name=self.name,
      )
    result.name = self.name
    return result

  def call(
      self,
      *,
      args: dict[str, Any],
      tool_context: ToolContext,
  ) -> Any:
    if self.agent.input_schema:
      input_value = self.agent.input_schema.model_validate(args)
    else:
      input_value = args['request']

    if self.agent.input_schema:
      if isinstance(input_value, dict):
        input_value = self.agent.input_schema.model_validate(input_value)
      if not isinstance(input_value, self.agent.input_schema):
        raise ValueError(
            f'Input value {input_value} is not of type {self.input_schema}.'
        )
      content = types.Content(
          role='user',
          parts=[
              types.Part.from_text(
                  text=input_value.model_dump_json(exclude_none=True)
              )
          ],
      )
    else:
      content = types.Content(
          role='user',
          parts=[types.Part.from_text(text=input_value)],
      )
    runner = InMemoryRunner(self.agent)
    session = runner.session_service.create(
        'tmp_app', 'tmp_user', state=tool_context.state.to_dict()
    )
    # TODO(ybo): Remove this hack to let agent_tool to chagne parent's session state.
    session.state = tool_context.state
    events = list(runner.run(session=session, new_message=content))
    last_event = events[-1]

    for artifact_name in runner.artifact_service.list_keys(session.id):
      tool_context.save_artifact(
          artifact_name,
          runner.artifact_service.load(session.id, artifact_name),
      )

    if self.agent.output_schema:
      tool_result = self.agent.output_schema.model_validate_json(
          last_event.content.parts[0].text
      ).model_dump(exclude_none=True)
    else:
      tool_result = last_event.content.parts[0].text
    return tool_result
