from .async_function_tool import AsyncFunctionTool
from .base_tool import BaseTool
from .function_tool import FunctionTool
from .get_user_choice_tool import get_user_choice_tool as get_user_choice
from .google_search_tool import google_search_tool as google_search
from .load_artifacts_tool import load_artifacts_tool as load_artifacts
from .tool_context import ToolContext


def exit_loop(tool_context: ToolContext):
  """Exits the loop.

  Call this function only when you are instructed to do so.
  """
  tool_context.actions.escalate = True


def transfer_to_agent(agent_name: str, tool_context: ToolContext):
  """Transfer the question to another agent."""
  tool_context.actions.transfer_to_agent = agent_name
