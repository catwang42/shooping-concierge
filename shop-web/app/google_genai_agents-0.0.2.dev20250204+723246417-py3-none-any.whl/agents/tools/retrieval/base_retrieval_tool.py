from google.genai import types

from .. import BaseTool


class BaseRetrievalTool(BaseTool):

  def __init__(self, *, name: str, description: str):
    super().__init__('retrieval', name, description)

  def get_declaration(self) -> types.FunctionDeclaration:
    return types.FunctionDeclaration(
        name=self.name,
        description=self.description,
        parameters=types.Schema(
            type='OBJECT',
            properties={
                'query': types.Schema(
                    type='STRING',
                    description='The query to retrieve.',
                ).model_dump(exclude_none=True),
            },
        ),
    )
