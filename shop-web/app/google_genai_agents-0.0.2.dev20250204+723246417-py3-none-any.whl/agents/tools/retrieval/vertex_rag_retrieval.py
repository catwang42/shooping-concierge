"""A retrieval tool that uses Vertex RAG to retrieve data."""

import logging
from typing import Any

from vertexai.preview import rag

from ..tool_context import ToolContext
from . import BaseRetrievalTool

logger = logging.getLogger(__name__)


class VertexRagRetrieval(BaseRetrievalTool):
  """A retrieval tool that uses Vertex RAG (Retrieval-Augmented Generation) to retrieve data."""

  def __init__(
      self,
      *,
      name: str,
      description: str,
      retrieval_config: dict[str, Any] = {},
  ):
    super().__init__(name=name, description=description)
    self.retrieval_config = retrieval_config

  def call(
      self,
      *,
      args: dict[str, Any],
      tool_context: ToolContext,
  ) -> Any:

    response = rag.retrieval_query(text=args["query"], **self.retrieval_config)

    logging.debug("RAG raw response: %s", response)

    return (
        f"No matching result found with the config: {self.retrieval_config}"
        if not response.contexts.contexts
        else [context.text for context in response.contexts.contexts]
    )
