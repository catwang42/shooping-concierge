"""Provides examples from vertex example store."""

from google.cloud.aiplatform.private_preview import example_stores
from google.genai import types
from .base_example_provider import BaseExampleProvider
from .example import Example


class VertexExampleStore(BaseExampleProvider):

  def __init__(self, examples_store_name: str):
    self.examples_store_name = examples_store_name

  def get_examples(self, query: str) -> list[Example]:
    example_store = example_stores.ExampleStore(self.examples_store_name)
    # Retrieve relevant examples.
    request = {
        "stored_contents_example_parameters": {
            "content_search_key": {
                "contents": [{"role": "user", "parts": [{"text": query}]}],
                "search_key_generation_method": {"last_entry": {}},
            }
        },
        "top_k": 10,
        "example_store": self.examples_store_name,
    }
    response = example_store.api_client.search_examples(request)

    # Convert results to genai formats
    for result in response.results:
      if result.similarity_score < 0.5:
        continue
      expected_contents = [
          content.content
          for content in result.example.stored_contents_example.contents_example.expected_contents
      ]
      expected_output = []
      for content in expected_contents:
        expected_parts = []
        for part in content.parts:
          if part.text:
            expected_parts.append(types.Part.from_text(text=part.text))
          elif part.function_call:
            expected_parts.append(
                types.Part.from_function_call(
                    name=part.function_call.name,
                    args={
                        key: value
                        for key, value in part.function_call.args.items()
                    },
                )
            )
          elif part.function_response:
            expected_parts.append(
                types.Part.from_function_response(
                    name=part.function_response.name,
                    response={
                        key: value
                        for key, value in part.function_response.response.items()
                    },
                )
            )
        expected_output.append(
            types.Content(role=content.role, parts=expected_parts)
        )

      yield Example(
          input=types.Content(
              role="user",
              parts=[
                  types.Part.from_text(
                      text=result.example.stored_contents_example.search_key
                  )
              ],
          ),
          output=expected_output,
      )
