import asyncio
import logging
from types import ModuleType
from typing import AsyncGenerator
from typing import Generator

from ...agents.invocation_context import InvocationContext
from ...agents.live_request_queue import LiveRequestQueue
from ...events import Event
from ...models import LlmRequest
from ...models import LlmResponse
from ...models.base_llm_connection import BaseLlmConnection
from ...models.registry import LLMRegistry
from ...telemetry import trace_call_llm
from ...telemetry import trace_send_data
from ...telemetry import tracer
from ...tools import BaseTool
from ...tools import ToolContext
from ..base_flow import BaseFlow
from . import functions
from websockets.exceptions import ConnectionClosedOK

logger = logging.getLogger(__name__)


def iter_over_async(ait, loop):
  ait = ait.__aiter__()

  async def get_next():
    try:
      obj = await ait.__anext__()
      return False, obj
    except StopAsyncIteration:
      return True, None

  while True:
    done, obj = loop.run_until_complete(get_next())
    if done:
      break
    yield obj


def sync_generator(async_gen):
  loop = asyncio.get_event_loop()
  sync_gen = iter_over_async(async_gen, loop)
  return sync_gen


class BaseLlmFlow(BaseFlow):
  """A basic flow that calls the LLM in a loop until a final response is generated.

  This flow ends when it transfer to another agent.
  """

  def __init__(self):
    self.request_processors: list[ModuleType] = []
    self.response_processors: list[ModuleType] = []

  async def call_live(
      self,
      invocation_context: InvocationContext,
  ) -> AsyncGenerator[Event, None]:
    """Process input asynchronously and yield events."""
    llm_request = LlmRequest()
    event_id = Event.new_id()

    # Preprocess before calling the LLM.
    for event in self._preprocess(invocation_context, llm_request):
      yield event
    if invocation_context.end_invocation:
      return

    llm = self.__get_llm(invocation_context)

    async with llm.connect(llm_request) as llm_connection:
      if llm_request.contents:
        # Sends the conversation history to the model.
        with tracer.start_as_current_span('send_data'):
          trace_send_data(invocation_context, event_id, llm_request.contents)
          await llm_connection.send_history(llm_request.contents)

      async with asyncio.TaskGroup() as tg:
        tg.create_task(
            self._send_to_model(
                llm_connection, invocation_context.live_request_queue
            )
        )
        async for event in self._receive_from_model(
            llm_connection,
            event_id,
            invocation_context,
            llm_request,
        ):
          # Empty event means the queue is closed.
          if not event:
            break
          yield event
          # In response to 'yield LlmResponse', there will be a new event that
          # contains the function responses.
          # TODO: Use a better way to get the response.
          last_event = invocation_context.session.events[-1]
          if last_event.get_function_responses():
            invocation_context.live_request_queue.send_content(
                last_event.content
            )

  async def _send_to_model(self, llm_connection, live_request_queue):
    while True:
      live_request = await live_request_queue.get()
      if live_request.close:
        await llm_connection.close()
        return
      if live_request.blob:
        await llm_connection.send_realtime(live_request.blob)
      if live_request.content:
        await llm_connection.send_content(live_request.content)

  async def _receive_from_model(
      self,
      llm_connection: BaseLlmConnection,
      event_id: str,
      invocation_context: InvocationContext,
      llm_request: LlmRequest,
  ) -> AsyncGenerator[Event, None]:
    """Receive data from model and process events using BaseLlmConnection."""
    assert invocation_context.live_request_queue
    try:
      while True:
        async for llm_response in llm_connection.receive():
          for event in self._postprocess(
              invocation_context, event_id, llm_request, llm_response
          ):
            yield event
        # Give opportunity for other tasks to run.
        await asyncio.sleep(0)
    except ConnectionClosedOK:
      pass

  def __call__(
      self,
      invocation_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    if invocation_context.streaming == 'server-socket':
      # Server-socket streaming mode.
      loop = asyncio.new_event_loop()
      asyncio.set_event_loop(loop)
      invocation_context.live_request_queue = LiveRequestQueue()
      for event in sync_generator(self.call_live(invocation_context)):
        yield event
        if event.turn_complete:
          invocation_context.live_request_queue.close()
    else:
      # Non-streaming mode.
      while True:
        last_event = None
        for event in self.__run_one_step(invocation_context):
          last_event = event
          yield event
        if not last_event or last_event.is_final_response():
          break

  def __run_one_step(
      self,
      invocation_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    """One step means one LLM call."""
    llm_request = LlmRequest()

    # Preprocess before calling the LLM.
    for event in self._preprocess(invocation_context, llm_request):
      yield event
    if invocation_context.end_invocation:
      return

    # Calls the LLM.
    event_id = Event.new_id()
    llm_response = self._call_llm(event_id, invocation_context, llm_request)

    # Postprocess after calling the LLM.
    yield from self._postprocess(
        invocation_context, event_id, llm_request, llm_response
    )

  def _preprocess(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ):
    # Runs processors.
    for processor in self.request_processors:
      events = processor.process_llm_request(invocation_context, llm_request)
      if events:
        yield from events

    # Run processors for tools.
    for tool in invocation_context.agent.tools:
      if isinstance(tool, BaseTool):
        tool_context = ToolContext(invocation_context)
        tool.process_llm_request(tool_context, llm_request)

  def _postprocess(
      self,
      invocation_context: InvocationContext,
      event_id: str,
      llm_request: LlmRequest,
      llm_response: LlmResponse,
  ) -> Generator[Event, None, None]:
    # Runs processors.
    for processor in self.response_processors:
      events = processor.process_llm_response(invocation_context, llm_response)
      if events:
        yield from events

    # Skip the model response event if there is no content and no error code.
    # This is needed for the code executor to trigger another loop.
    if not llm_response.content and not llm_response.error_code:
      return

    # Builds the event.
    model_response_event = self._build_model_response_event(
        event_id, invocation_context, llm_request, llm_response
    )
    yield model_response_event

    # Handles function calls.
    if model_response_event.get_function_calls():
      function_response_event = functions.handle_function_calls(
          invocation_context, model_response_event, llm_request.tools_dict
      )
      yield function_response_event

      transfer_to_agent = function_response_event.actions.transfer_to_agent
      if transfer_to_agent:
        root_agent = invocation_context.agent.get_root_agent()
        agent_to_run = root_agent.find_agent(transfer_to_agent)
        yield from agent_to_run.run(invocation_context)

  @tracer.start_as_current_span('call_llm')
  def _call_llm(
      self,
      event_id: str,
      invocation_context: InvocationContext,
      llm_request: LlmRequest,
  ) -> LlmResponse:
    # Runs before_model_callback if it exists.
    agent = invocation_context.agent
    if agent.before_model_callback:
      response = agent.before_model_callback(invocation_context, llm_request)
      if response:
        return response

    # Calls the LLM.
    llm = self.__get_llm(invocation_context)
    llm_responses = list(llm.generate_content(llm_request))
    trace_call_llm(invocation_context, event_id, llm_request, llm_responses)
    llm_response = llm_responses[0]

    # Runs after_model_callback if it exists.
    if agent.after_model_callback:
      response = agent.after_model_callback(invocation_context, llm_response)
      if response:
        return response

    return llm_response

  def _build_model_response_event(
      self,
      event_id: str,
      invocation_context: InvocationContext,
      llm_request: LlmRequest,
      llm_response: LlmResponse,
  ) -> Event:
    model_response_event = Event.from_llm_response(
        id=event_id,
        invocation_id=invocation_context.invocation_id,
        author=invocation_context.agent.name,
        llm_response=llm_response,
    )

    if model_response_event.content:
      function_calls = model_response_event.get_function_calls()
      if function_calls and functions.has_async_function_calls(
          function_calls, llm_request.tools_dict
      ):
        model_response_event.actions.pending = True
    return model_response_event

  def __get_llm(self, invocation_context: InvocationContext):
    resolved_model = invocation_context.agent.resolved_model
    return (
        LLMRegistry.new_llm(resolved_model)
        if isinstance(resolved_model, str)
        else resolved_model
    )
