"""Implementation of single flow."""

import logging
from . import _code_execution
from . import _nl_planning
from . import basic
from . import contents
from . import examples
from . import identity
from . import instructions
from .base_llm_flow import BaseLlmFlow

logger = logging.getLogger(__name__)


class SingleFlow(BaseLlmFlow):
  """SingleFlow is the LLM flows that handles tools calls.

  A single flow only consider an agent itself and tools.
  No children agents are allowed for unit flow.
  """

  def __init__(self):
    super().__init__()
    self.request_processors += [
        basic,
        instructions,
        identity,
        examples,
        _nl_planning,
        contents,
        # Code execution should be after the contents as it mutates the contents
        # to optimize data files.
        _code_execution,
    ]
    self.response_processors += [
        _nl_planning,
        _code_execution,
    ]
