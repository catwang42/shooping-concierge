"""Handles basic information to build the LLM request."""

from google.genai import types

from ...agents.invocation_context import InvocationContext
from ...models import LlmRequest


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):
  agent = invocation_context.agent
  llm_request.model = (
      agent.resolved_model
      if isinstance(agent.resolved_model, str)
      else agent.resolved_model.model
  )
  llm_request.config = (
      agent.generate_content_config.model_copy(deep=True)
      if agent.generate_content_config
      else types.GenerateContentConfig()
  )
  # Initialize the tools list.
  llm_request.config.tools = []
  llm_request.append_tools(invocation_context.agent.tools)
  if agent.output_schema:
    llm_request.set_output_schema(agent.output_schema)
  if invocation_context.response_modalities:
    llm_request.config.response_modalities = (
        invocation_context.response_modalities
    )
