"""Handles instructions and global instructions for LLM flow."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING
from typing import Callable

if TYPE_CHECKING:
  from ...agents.agent import InstructionBuilder
  from ...agents.invocation_context import InvocationContext
  from ...models import LlmRequest


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
) -> LlmRequest:
  agent = invocation_context.agent

  # Appends global instructions if set.
  root_agent = invocation_context.agent.get_root_agent()
  if root_agent.global_instruction:
    si = _build_system_instruction(
        invocation_context, root_agent.global_instruction
    )
    llm_request.append_instructions([si])

  # Appends agent instructions if set.
  if agent.instruction:
    si = _build_system_instruction(invocation_context, agent.instruction)
    llm_request.append_instructions([si])


def _build_system_instruction(
    invocation_context: InvocationContext,
    instruction: str | InstructionBuilder,
) -> str:
  """Builds system instruction from instruction and session."""
  if isinstance(instruction, Callable):
    si = instruction(invocation_context)
  else:
    si = instruction
  return _populate_values(si, invocation_context)


def _populate_values(
    instruction_template: str,
    context: InvocationContext,
) -> str:
  def _replace_match(match) -> str:
    var_name = match.group().lstrip('{').rstrip('}').strip()
    optional = False
    if var_name.endswith('?'):
      optional = True
      var_name = var_name.removesuffix('?')
    if var_name.startswith('artifact.'):
      var_name = var_name.removeprefix('artifact.')
      artifact = context.artifact_service.load(context.session.id, var_name)
      if not var_name:
        raise KeyError(f'Artifact {var_name} not found.')
      return str(artifact)
    else:
      if not var_name.isidentifier():
        return match.group()
      if var_name in context.session.state:
        return str(context.session.state[var_name])
      else:
        if optional:
          return ''
        else:
          raise KeyError(f'Context variable {var_name} not found.')
  return re.sub(r'{+[^{}]*}+', _replace_match, instruction_template)
