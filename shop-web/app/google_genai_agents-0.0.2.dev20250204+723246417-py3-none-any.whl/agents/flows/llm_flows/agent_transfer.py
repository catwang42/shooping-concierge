"""Handles agent transfer for LLM flow."""

import typing

from ...agents.invocation_context import InvocationContext
from ...models import LlmRequest
from ...tools import transfer_to_agent

if typing.TYPE_CHECKING:
  from ...agents import Agent
  from ...agents import BaseAgent


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):
  transfer_targets = __get_transfer_targets(invocation_context.agent)
  if not transfer_targets:
    return

  llm_request.append_instructions([
      __build_target_agents_instructions(
          invocation_context.agent, transfer_targets
      )
  ])

  llm_request.append_tools([transfer_to_agent])


def __build_target_agents_info(target_agent: 'BaseAgent') -> str:
  return f"""
Agent name: {target_agent.name}
Agent description: {target_agent.description}
"""


line_break = '\n'


def __build_target_agents_instructions(
    agent: 'Agent', target_agents: list['BaseAgent']
) -> str:
  si = f"""
You have a list of other agents to transfer to:

{line_break.join([
    __build_target_agents_info(target_agent) for target_agent in target_agents
])}

If you are the best to answer the question according to your description, you
can answer it.

If another agent is better for answering the question according to its
description, call `{_TRANSFER_TO_AGENT_FUNCTION_NAME}` function to transfer the
question to that agent. When transfering, do not generate any text other than
the function call.
"""

  if agent.parent_agent:
    si += f"""
Your parent agent is {agent.parent_agent.name}. If neither the other agents nor
you are best for answering the question according to the descriptions, transfer
to your parent agent. If you don't have parent agent, try answer by yourself.
"""
  return si


_TRANSFER_TO_AGENT_FUNCTION_NAME = transfer_to_agent.__name__


def __get_transfer_targets(agent: 'Agent') -> list['BaseAgent']:
  result = []
  result.extend(agent.children)

  if agent.parent_agent and not agent.disable_sibling_agent_transfer:
    result.append(agent.parent_agent)
    for sibling in agent.parent_agent.children:
      if sibling.name != agent.name:
        result.append(sibling)

  return result
