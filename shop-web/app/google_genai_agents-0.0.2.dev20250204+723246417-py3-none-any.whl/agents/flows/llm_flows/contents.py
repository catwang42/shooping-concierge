"""Builds the contents for the LLM request."""

import copy

from google.genai import types

from ...agents.invocation_context import InvocationContext
from ...events import Event
from ...models import LlmRequest


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):
  agent = invocation_context.agent
  if agent.include_contents != 'none':
    llm_request.contents = _get_contents(
        invocation_context.session.events, agent.name
    )


def _rearrange_events_for_async_function_responses_in_history(
    events: list[Event],
) -> list[Event]:
  """Rearrange the async function_response events in the history."""

  function_response_events_dict: dict[str, list[Event]] = {}
  for event in events:
    if event.get_function_responses():
      function_call_event_id: str = event.function_call_event_id  # type: ignore
      function_response_events = function_response_events_dict.get(
          function_call_event_id, []
      )
      function_response_events.append(event)
      function_response_events_dict[function_call_event_id] = (
          function_response_events
      )

  result_events: list[Event] = []
  for event in events:
    if event.get_function_responses():
      # function_response should be handled together with function_call below.
      continue
    elif event.get_function_calls():
      function_call_event_id = event.id
      function_response_events = function_response_events_dict.get(
          function_call_event_id, []
      )
      if not function_response_events:
        raise ValueError(
            'No matching function_response event found for id:'
            f' {function_call_event_id}'
        )
      result_events.append(event)
      if len(function_response_events) == 1:
        result_events.append(function_response_events[0])
      else:  # Merge all async function_response as one response event
        result_events.append(
            __merge_async_function_response_events(function_response_events)
        )
      continue
    else:
      result_events.append(event)

  return result_events


def _rearrange_events_for_latest_function_response(
    events: list[Event],
) -> list[Event]:
  """Rearrange the events for the latest function_response.

  If the latest function_response is for an async function_call, all events
  bewteen the initial function_call and the latest function_response will be
  removed.
  """
  if not events:
    return events
  if not events[-1].get_function_responses():
    # No need to process, since the latest event is not fuction_response.
    return events

  function_call_event_id = events[-1].function_call_event_id
  if events[-2].id == function_call_event_id:
    # The latest function_response is already matched
    return events

  reversed_function_response_events: list[Event] = []
  function_call_event_idx = -1
  for revered_idx, event in enumerate(reversed(events)):
    if event.id == function_call_event_id:
      function_call_event_idx = len(events) - 1 - revered_idx
      break
    elif (
        event.get_function_responses()
        and event.function_call_event_id == function_call_event_id
    ):
      reversed_function_response_events.append(event)

  if function_call_event_idx == -1:
    raise ValueError(
        f'No function call event found for id: {function_call_event_id}'
    )

  result_events = events[: function_call_event_idx + 1]
  result_events.append(
      __merge_async_function_response_events(
          list(reversed(reversed_function_response_events))
      )
  )
  return result_events


def _get_contents(
    events: list[Event], agent_name: str = ''
) -> list[types.Content]:
  filtered_events = []
  # Filter the events, leaving the contents and the function calls and
  # responses from the current agent.
  for event in events:
    if event.is_greeting:
      # Does not include the greeting message because it results in a low
      # agent transfer rate.
      continue
    if event.content:
      # Filter out function calls and responses that belong to other agents.
      # Otherwise the current agent will hallucinate and call the function.
      # TODO: Handle the case if both text and function call/response are
      # present.
      if (
          agent_name
          and event.author != agent_name
          and event.author != 'user'
          and (event.get_function_calls() or event.get_function_responses())
      ):
        continue
      filtered_events.append(event)
  result_events = _rearrange_events_for_latest_function_response(
      filtered_events
  )
  result_events = _rearrange_events_for_async_function_responses_in_history(
      result_events
  )
  return [copy.deepcopy(e.content) for e in result_events]


def __merge_async_function_response_events(
    async_function_response_events: list['Event'],
) -> 'Event':
  """Merges a list of function_response events into one event for async

  function_call.

  The key goal is to ensure:
  1. function_call and function_response are always of the same number.
  2. The function_call and function_response are consecutively in the content.

  Args:
    async_function_response_events: A list of function_response events.
      NOTE: function_response_events must fulfill these requirements: 1. The
        list is in increasing order of timestamp; 2. the first event is the
        initial function_reponse event; 3. all later events should contain at
        least one function_response part that related to the function_call
        event.
      Caveat: This implementation doesn't support when a parallel
        function_call event contains async function_call of the same name.

  Returns:
    A merged event, that is
      1. All later function_response will replace function_response part in
          the initial function_response event.
      2. All non-function_response parts will be appended to the part list of
          the initial function_response event.
  """
  if len(async_function_response_events) <= 1:
    raise ValueError('At least two function_response events are required.')

  merged_event = async_function_response_events[0].model_copy(deep=True)
  parts_in_merged_event: list[types.Part] = merged_event.content.parts  # type: ignore

  if not parts_in_merged_event:
    raise ValueError('There should be at least one function_response part.')

  part_indices_in_merged_event: dict[str, int] = {}
  for idx, part in enumerate(parts_in_merged_event):
    if part.function_response:
      func_name: str = part.function_response.name  # type: ignore
      part_indices_in_merged_event[func_name] = idx

  for event in async_function_response_events[1:]:
    if not event.content.parts:
      raise ValueError('There should be at least one function_response part.')

    for part in event.content.parts:
      if part.function_response:
        func_name: str = part.function_response.name  # type: ignore
        parts_in_merged_event[part_indices_in_merged_event[func_name]] = part
      else:
        parts_in_merged_event.append(part)

  return merged_event
