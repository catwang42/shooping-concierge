from abc import ABC
from abc import abstractmethod
from typing import Generator

from ..events import Event
from ..agents.invocation_context import InvocationContext


class BaseFlow(ABC):
  """Interface for the execution flows to run a group of agents."""

  @abstractmethod
  def __call__(
      self,
      invocation_context: InvocationContext
  ) -> Generator[Event, None, None]:
    """Run this flow.

    To extend, the flow should follow the below requirements:

    1. `session` should be treated as immutable, DO NOT change it.

    2. The caller who trigger the flow is responsible for updating the session
    as the events being generated. The subclass implentation will assume
    session is updated after each yield event statement.

    3. A flow may spawn children flows dependeing on the agent definition.
    """
    pass
