from typing import Generator

from ..agents.invocation_context import InvocationContext
from ..events import Event
from .base_flow import BaseFlow


class LoopFlow(BaseFlow):
  def __init__(self, max_iterations: int = 0):
    self.max_iterations = max_iterations

  # Runs children in sequence unless one agent sets escalate action.
  def __call__(
      self,
      invocation_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    times_looped = 0
    while True:
      for child in invocation_context.agent.children:
        for event in child.run(invocation_context):
          yield event
          # Escalating means ending the loop.
          if event.actions.escalate:
            return
      times_looped += 1
      if self.max_iterations and times_looped >= self.max_iterations:
        return
