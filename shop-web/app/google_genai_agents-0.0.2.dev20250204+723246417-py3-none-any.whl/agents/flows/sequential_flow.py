from typing import Generator

from ..agents.invocation_context import InvocationContext
from ..events import Event
from .base_flow import BaseFlow


class SequentialFlow(BaseFlow):

  def __call__(
      self,
      invocation_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    for child in invocation_context.agent.children:
      yield from child.run(invocation_context)
