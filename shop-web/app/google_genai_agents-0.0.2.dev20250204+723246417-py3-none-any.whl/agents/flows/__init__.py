from .base_flow import BaseFlow
from .llm_flows.auto_flow import AutoFlow
from .llm_flows.single_flow import SingleFlow
from .loop_flow import LoopFlow
from .registry import FlowRegistry
from .sequential_flow import SequentialFlow

__all__ = [
    'AutoFlow',
    'BaseFlow',
    'FlowRegistry',
    'LoopFlow',
    'SequentialFlow',
    'SingleFlow',
]


FlowRegistry.register('loop', LoopFlow)
FlowRegistry.register('sequential', SequentialFlow)
FlowRegistry.register('unit', SingleFlow)
FlowRegistry.register('auto', AutoFlow)
FlowRegistry.register('single', SingleFlow)
