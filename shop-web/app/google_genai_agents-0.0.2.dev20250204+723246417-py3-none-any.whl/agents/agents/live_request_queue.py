import asyncio
from google.genai import types
from pydantic import BaseModel


class _LiveRequest(BaseModel):
  content: types.Content | None = None
  """If set, send the content to the model in turn-by-turn mode."""
  blob: types.Blob | None = None
  """If set, send the blob to the model in realtime mode."""
  close: bool = False
  """If set, close the queue. queue.shutdown() is only supported in Python 3.13+."""


class LiveRequestQueue:

  def __init__(self):
    self._queue = asyncio.Queue()

  def close(self):
    self._queue.put_nowait(_LiveRequest(close=True))

  def send_content(self, content: types.Content):
    self._queue.put_nowait(_LiveRequest(content=content))

  def send_realtime(self, blob: types.Blob):
    self._queue.put_nowait(_LiveRequest(blob=blob))

  async def get(self) -> _LiveRequest:
    return await self._queue.get()
