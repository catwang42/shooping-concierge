from typing import Generator
from google.genai import types
from pydantic import ConfigDict
from ..events import Event
from .base_agent import BaseAgent
from .invocation_context import InvocationContext
from langgraph.graph.graph import CompiledGraph


class LangGraphAgent(BaseAgent):
  """Currently just a concept implementation, only supports single turn."""

  model_config = ConfigDict(
      arbitrary_types_allowed=True,
  )

  graph: CompiledGraph

  def run(
      self,
      parent_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    from langchain_core.messages import HumanMessage

    messages = []
    for event in parent_context.session.events:
      if event.author == 'user':
        messages.append(HumanMessage(content=event.content.parts[0].text))

    # Use the Runnable
    final_state = self.graph.invoke({'messages': messages})
    result = final_state['messages'][-1].content

    result_event = Event(
        invocation_id=parent_context.invocation_id,
        author=self.name,
        content=types.Content(
            role='model',
            parts=[types.Part.from_text(result)],
        ),
    )
    yield result_event
