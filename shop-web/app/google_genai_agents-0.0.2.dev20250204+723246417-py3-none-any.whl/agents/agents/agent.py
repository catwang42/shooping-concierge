import logging
from functools import cached_property
from typing import Any
from typing import AsyncGenerator
from typing import Callable
from typing import Generator
from typing import Literal

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import field_validator

from ..code_executor.base_code_executor import BaseCodeExecutor
from ..events import Event
from ..examples import BaseExampleProvider
from ..examples import Example
from ..flows.base_flow import BaseFlow
from ..flows.registry import FlowRegistry
from ..models import BaseLlm
from ..models import LlmRequest
from ..models import LlmResponse
from ..telemetry import tracer
from ..tools import BaseTool
from ..tools import ToolContext
from .base_agent import BaseAgent
from .callback_context import CallbackContext
from .invocation_context import InvocationContext

logger = logging.getLogger(__name__)


BeforeModelCallback = Callable[
    [InvocationContext, LlmRequest], LlmResponse | None
]
AfterModelCallback = Callable[
    [InvocationContext, LlmResponse],
    LlmResponse | None,
]
BeforeAgentCallback = Callable[[CallbackContext], types.Content | None]
AfterAgentCallback = Callable[[CallbackContext], types.Content | None]
BeforeToolCallback = Callable[
    [BaseTool, dict[str, Any], ToolContext],
    dict | None,
]
AfterToolCallback = Callable[
    [BaseTool, dict[str, Any], ToolContext, dict],
    dict | None,
]
InstructionProvider = Callable[[InvocationContext], str]

ToolUnion = Callable | BaseTool

ExamplesUnion = list[Example] | BaseExampleProvider

FlowCallable = Callable[[InvocationContext], Generator[Event, None, None]]


class Agent(BaseAgent):
  """The LLM-based agent."""

  model_config = ConfigDict(
      arbitrary_types_allowed=True,
      extra='forbid',
  )

  model: str | BaseLlm = ''
  """The model to use for the agent.

  When not set, the agent will inherit the model from its parent agent.
  """

  instruction: str | InstructionProvider = ''
  """Instructions for the LLM model, guiding the agent's behavior."""

  global_instruction: str | InstructionProvider = ''
  """Instructions for all the children agents in the entire agent tree.
  Only allowd in root agent.
  You can use this instruction to set up a stable identify or personality across all child agents."""

  flow: str | BaseFlow | FlowCallable = 'single'
  children: list[BaseAgent] = []
  tools: list[ToolUnion] = []
  generate_content_config: types.GenerateContentConfig | None = None
  examples: ExamplesUnion | None = None
  greeting_prompt: str | None = None

  planning: bool = False
  """If true, the agent will be instructed to make a plan and execute it step by
  step. Default to false.
  """

  code_executor: BaseCodeExecutor | None = None
  """If set, the agent will execute the code blocks from model responses and
  incorporate the code execution results into its final response.
  Default to None.
  """

  disable_sibling_agent_transfer: bool = False
  """If true, the agent will not be able to transfer the question to its sibling
  agents. Default to false.
  """

  input_schema: type[BaseModel] | None = None
  output_schema: type[BaseModel] | None = None
  output_key: str | None = None
  """If set, the output of the agent will be stored in the state under this key.
  """

  include_contents: Literal['default', 'none'] | None = None
  """Control the contents to include in the model request.

  'default': All contents are included.
  'none': No contents are included.
  """

  before_model_callback: BeforeModelCallback | None = None
  """Called before the model is called.

  If the returned response is not None, the model will not be called.

  Args:
    invocation_context: The invocation context.
    request: The raw model request. Callback can mutate the request.
  """

  after_model_callback: AfterModelCallback | None = None
  """Called after the model is called.

  The returned response takes precedence over the model response.

  Args:
    invocation_context: The invocation context.
    generate_content_response: The raw model response, of which the content will
      be added to the event.
  """

  before_agent_callback: BeforeAgentCallback | None = None
  """Called before the agent is called.

  If the returned content is not None, it will be added to the session and the
  agent will not be called.

  Args:
    callback_context: CallbackContext,

  Returns:
    The content to return to the user.
  """

  after_agent_callback: AfterAgentCallback | None = None
  """Called after the agent is called.

  If the returned content is not None, it will be added to the session.

  Args:
    invocation_context: InvocationContext,
  """

  before_tool_callback: BeforeToolCallback | None = None
  """Called before the tool is called.

  If you return an object, that object will be used as the tool response.
  Otherwise, the tool will be called.

  Args:
    invocation_context: InvocationContext,
    tool: The tool to be called.
    args: The arguments to the tool.
    tool_context: ToolContext,

  Returns:
    The tool response event or None to let the framework call the tool.
  """

  after_tool_callback: AfterToolCallback | None = None
  """Called after the tool is called.

  If you return an object, that object will be used as the tool response.
  Otherwise, the tool will be called.

  Args:
    invocation_context: InvocationContext,
    tool: The tool to be called.
    args: The arguments to the tool.
    tool_context: ToolContext,
    tool_response: The response from the tool.

  Returns:
    None
  """

  @field_validator('name', mode='after')
  @classmethod
  def validate_agent(cls, name: str) -> Any:
    if not name.isidentifier():
      raise ValueError(f'Agent name `{name}` is invalid.')
    return name

  @field_validator('generate_content_config', mode='after')
  @classmethod
  def validate_generate_content_config(
      cls, generate_content_config: types.GenerateContentConfig
  ) -> types.GenerateContentConfig:
    if not generate_content_config:
      return types.GenerateContentConfig()
    if generate_content_config.tools:
      raise ValueError('All tools must be set via Agent.tools.')
    if generate_content_config.system_instruction:
      raise ValueError('System instruction must be set via Agent.instruction.')
    if generate_content_config.response_schema:
      raise ValueError('Response schema must be set via Agent.output_schema.')
    return generate_content_config

  # Get the model name from the agent or its parent agent.
  def get_model(self):
    agent = self
    while agent:
      if agent.model:
        return agent.model
      agent = agent.parent_agent
    raise ValueError(f'No model found for agent {self.name}.')

  def find_child(self, name: str) -> BaseAgent | None:
    """Finds the child agent with the given name recursively."""
    for child in self.children:
      if child.name == name:
        return child
      # Other agent types do not have children.
      if isinstance(child, Agent):
        result = child.find_child(name)
        if result:
          return result
    return None

  def find_agent(self, name: str) -> BaseAgent | None:
    """Similar to find_child, but also check itself."""
    if self.name == name:
      return self
    return self.find_child(name)

  def model_post_init(self, __context):
    for child in self.children:
      if child.parent_agent:
        logger.error(
            'Agent %s already has a parent agent %s.',
            child.name,
            child.parent_agent.name,
        )
        raise ValueError(
            f'Agent {child.name} already has a parent agent'
            f' {child.parent_agent.name}.'
        )
      child.parent_agent = self

  def _handle_output_key(self, event, output_key, output_schema):
    """Processes the final response of an event and updates the state delta."""
    if output_key and event.is_final_response():
      result = event.content.parts[0].text
      if output_schema:
        result = output_schema.model_validate_json(result).model_dump(
            exclude_none=True
        )
      event.actions.state_delta[output_key] = result

  async def run_live(
      self,
      parent_context: InvocationContext,
  ) -> AsyncGenerator[Event, None]:
    with tracer.start_as_current_span(f'call_agent [{self.name}]'):
      # Always creates a new invocation context for the current agent.
      invocation_context = parent_context.model_copy(update={'agent': self})

      async for event in self.__resolved_flow.call_live(invocation_context):
        self._handle_output_key(event, self.output_key, self.output_schema)
        yield event
      if invocation_context.end_invocation:
        return

  def run(
      self,
      parent_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    with tracer.start_as_current_span(f'call_agent [{self.name}]'):
      # Always creates a new invocation context for the current agent.
      invocation_context = parent_context.model_copy(update={'agent': self})

      # Run before_agent_callback if it exists.
      if self.before_agent_callback is not None:
        callback_context = CallbackContext(invocation_context)
        before_agent_callback_content = self.before_agent_callback(
            callback_context
        )
        if before_agent_callback_content:
          yield Event(
              invocation_id=invocation_context.invocation_id,
              author=self.name,
              content=before_agent_callback_content,
              actions=callback_context._event_actions,
          )
          return
        # TODO(wesiun): Double check below:
        #   1. UI and runner can handle this.
        #   2. session save will save this.
        if callback_context.state.has_delta():
          yield Event(
              invocation_id=invocation_context.invocation_id,
              author=self.name,
              actions=callback_context._event_actions,
          )
        if invocation_context.end_invocation:
          return

      # Run the flow.
      events = self.__resolved_flow(invocation_context)
      if events:
        for event in events:
          self._handle_output_key(event, self.output_key, self.output_schema)
          yield event
      if invocation_context.end_invocation:
        return

      # Run after_agent_callback if it exists.
      if self.after_agent_callback is not None:
        callback_context = CallbackContext(invocation_context)
        after_agent_callback_content = self.after_agent_callback(
            callback_context
        )
        if after_agent_callback_content or callback_context.state.has_delta():
          yield Event(
              invocation_id=invocation_context.invocation_id,
              author=self.name,
              content=after_agent_callback_content,
              actions=callback_context._event_actions,
          )
        if invocation_context.end_invocation:
          return

  @cached_property
  def children_dict(self) -> dict[str, BaseAgent]:
    """Returns a dict of children agents keyed by their names."""
    return {agent.name: agent for agent in self.children}

  @cached_property
  def resolved_model(self) -> str | BaseLlm:
    current_agent = self
    while current_agent:
      if current_agent.model:
        return current_agent.model
      current_agent = current_agent.parent_agent
    raise ValueError(f'No model found for agent {self.name}.')

  @cached_property
  def __resolved_flow(self) -> FlowCallable:
    if isinstance(self.flow, str):
      return FlowRegistry.new_flow(self.flow)
    if isinstance(self.flow, BaseFlow):
      return self.flow
    if isinstance(self.flow, Callable):
      return self.flow
    raise ValueError(f'Unsupported flow type: {type(self.flow)}')
