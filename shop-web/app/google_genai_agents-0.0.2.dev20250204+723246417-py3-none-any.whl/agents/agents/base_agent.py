from abc import ABC
from abc import abstractmethod
import typing
from typing import Generator

from pydantic import BaseModel
from pydantic import Field

from ..events import Event

if typing.TYPE_CHECKING:
  from .invocation_context import InvocationContext


class BaseAgent(BaseModel, ABC):
  """Base class for all agents."""

  name: str
  """The agent's name.

  Agent name must be a unique Python identifier within the agent tree.
  """

  description: str = ''
  """One line description about the agent's capability.

  The model uses this to determine whether to delegate control to the agent.
  """

  parent_agent: 'BaseAgent | None' = Field(default=None, init=False)
  """The parent agent in the agent tree.

  Note that one agent cannot be added to two agents' children list.
  """

  @abstractmethod
  def run(
      self,
      parent_context: 'InvocationContext',
  ) -> Generator[Event, None, None]:
    pass

  def get_root_agent(self) -> 'BaseAgent | None':
    agent = self
    while agent:
      if agent.parent_agent is None:
        return agent
      agent = agent.parent_agent
    return None
