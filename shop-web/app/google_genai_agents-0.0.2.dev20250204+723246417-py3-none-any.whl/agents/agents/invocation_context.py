from typing import Literal

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict

from ..artifacts.base_artifact_service import BaseArtifactService
from ..sessions.base_session_service import BaseSessionService
from ..sessions.session import Session
from .base_agent import BaseAgent
from .live_request_queue import LiveRequestQueue


# An invocation context represents the data of a single invocation of an agent.
#
# An invocation:
#   1. Starts with a user message and ends with a final response.
#   2. Can contain one or multiple agent calls.
#   3. Is handled by runner.run().
# An invocation runs an agent until it does not request to transfer to another
# agent.
#
# An agent call:
#   1. Is handled by agent.run().
#   2. Ends when agent.run() ends.
#
# An LLM agent call is an agent with a BaseLLMFlow.
# An LLM agent call can contain one or multiple steps.
# An LLM agent runs steps in a loop until:
#   1. A final reponse is generated.
#   2. The agent transfers to another agent.
#   3. The end_invocation is set to true by any callbacks or tools.
#
# A step:
#   1. Calls the LLM only once and yields its response.
#   2. Calls the tools and yields their responses if requested.
# The summarization of the function response is considered another step, since
# it is another llm call.
# A step ends when it's done calling llm and tools, or if the end_invocation
# is set to true at any time.
#
#
# ┌─────────────────────── invocation ──────────────────────────┐
# ┌──────────── llm_agent_call_1 ────────────┐ ┌─ agent_call_2 ─┐
# ┌──── step_1 ────────┐ ┌───── step_2 ──────┐
# [call_llm] [call_tool] [call_llm] [transfer]
class InvocationContext(BaseModel):
  model_config = ConfigDict(
      arbitrary_types_allowed=True,
      extra='forbid',
  )

  artifact_service: BaseArtifactService
  session_service: BaseSessionService

  invocation_id: str
  """The id of this invocation context. Readonly."""
  agent: BaseAgent
  """The current agent of this invocation context. Readonly."""
  user_content: types.Content | None = None
  """The user content that started this invocation. Readonly."""
  session: Session
  """The current session of this invocation context. Readonly."""
  streaming: Literal[None, '', 'server-socket', 'bidi'] = ''
  """Streaming mode, None or 'server-socket'."""

  end_invocation: bool = False
  """Whether to end this invocation.

  Set to True in callbacks or tools to terminate this invocation."""

  live_request_queue: LiveRequestQueue | None = None
  """The queue to receive live requests."""

  response_modalities: list[str] | None = None
  """The output modalities of this invocation."""
