from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict


class LlmResponse(BaseModel):
  model_config = ConfigDict(extra='forbid')

  content: types.Content | None = None
  grounding_metadata: types.GroundingMetadata | None = None

  partial: bool | None = None
  """Indicates whether the text content is part of a unfinished text stream.

  Only used for streaming mode and when the content is plain text.
  """

  turn_complete: bool | None = None
  """Indicates whether the response from the model is complete.

  Only used for streaming mode.
  """

  error_code: str | None = None
  """Error code if the response is an error. Code varies by model."""

  error_message: str | None = None
  """Error message if the response is an error."""

  @staticmethod
  def create(
      generate_content_response: types.GenerateContentResponse,
  ) -> 'LlmResponse':
    if generate_content_response.candidates:
      candidate = generate_content_response.candidates[0]
      if candidate.content:
        return LlmResponse(
            content=candidate.content,
            grounding_metadata=candidate.grounding_metadata,
        )
      else:
        return LlmResponse(
            error_code=candidate.finish_reason,
            error_message=candidate.finish_message,
        )
    else:
      if generate_content_response.prompt_feedback:
        prompt_feedback = generate_content_response.prompt_feedback
        return LlmResponse(
            error_code=prompt_feedback.block_reason,
            error_message=prompt_feedback.block_reason_message,
        )
      else:
        return LlmResponse(
            error_code='UNKNOWN_ERROR',
            error_message='Unknown error.',
        )
