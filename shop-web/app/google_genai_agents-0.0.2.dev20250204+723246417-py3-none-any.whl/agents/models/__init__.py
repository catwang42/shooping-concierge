"""Defines the interface to support a model."""

from .base_llm import BaseLlm
from .google_llm import Gemini
from .llm_request import LlmRequest
from .llm_response import LlmResponse
from .registry import LLMRegistry

__all__ = [
    'BaseLlm',
    'Gemini',
    'LLMRegistry',
]


for regex in Gemini.supported_models():
  LLMRegistry.register(Gemini)
