import importlib
from typing import Any
from typing import Callable
from typing import Dict
from typing import Optional

from google.genai import types

from agents.artifacts import InMemoryArtifactService
from agents.sessions import InMemorySessionService
from agents.sessions import Session

from ..agents.agent import BaseAgent
from ..agents.agent import BeforeToolCallback
from ..runners import Runner
from .evaluation_constants import EvalConstants


class EvaluationGenerator:
  """Generates evaluation responses for agents."""

  @staticmethod
  def generate_responses(
      eval_dataset, agent_module_path, repeat_num=3, agent_name=None
  ):

    module_name = agent_module_path.split("/")[
        -1
    ]  # e.g., 'home_automation_agent'
    results = []

    for _ in range(repeat_num):
      for data in eval_dataset:
        results.append(
            EvaluationGenerator._process_query(
                data, agent_module_path, agent_name
            )
        )

    return results

  @staticmethod
  def generate_responses_from_session(session_path, eval_dataset):
    results = []

    with open(session_path, "r") as f:
      session_data = Session.model_validate_json(f.read())
      print("loaded session", session_path)

    for data in eval_dataset:
      # load session data from session_path
      results.append(
          EvaluationGenerator._process_query_with_session(
              session_data,
              data,
          )
      )

    return results

  @staticmethod
  def _process_query(data, module_name, agent_name=None):
    """
    Process a query using the agent and evaluation dataset.
    """
    module_path = f"{module_name}"
    agent_module = importlib.import_module(module_path)
    root_agent = agent_module.agent.root_agent

    # we don't know which tools belong to which agent
    # so we just apply to any agents that has certain tool outputs
    all_mock_tools = set()
    for eval_entry in data:
      expected_tool_use = eval_entry.get(EvalConstants.EXPECTED_TOOL_USE, [])
      for expected in expected_tool_use:
        if EvalConstants.MOCK_TOOL_OUTPUT in expected:
          all_mock_tools.add(expected[EvalConstants.TOOL_NAME])

    eval_data_copy = data.copy()
    EvaluationGenerator.apply_before_tool_callback(
        root_agent,
        lambda *args: EvaluationGenerator.before_tool_callback(
            *args, eval_dataset=eval_data_copy
        ),
        all_mock_tools,
    )

    session_service = InMemorySessionService()
    session = session_service.create("test", "test_user_id")
    artifact_service = InMemoryArtifactService()
    runner = Runner(
        "EvaluationGenerator", root_agent, artifact_service, session_service
    )

    # Reset agent state for each query
    reset_func = getattr(agent_module.agent, "reset_data", None)
    if callable(reset_func):
      reset_func()

    responses = data.copy()

    for index, eval_entry in enumerate(responses):
      response = None
      query = eval_entry["query"]
      content = types.Content(role="user", parts=[types.Part(text=query)])
      turn_actual_tool_uses = []

      for event in runner.run(session=session, new_message=content):
        if event.is_final_response():
          response = event.content.parts[0].text
        elif event.get_function_calls():
          for call in event.get_function_calls():
            turn_actual_tool_uses.append({
                EvalConstants.TOOL_NAME: call.name,
                EvalConstants.TOOL_INPUT: call.args,
            })

      responses[index]["actual_tool_use"] = turn_actual_tool_uses
      responses[index]["response"] = response

    return responses

  @staticmethod
  def _process_query_with_session(session_data, data):
    """
    Process the queries using the existing session data without invoking the runner.
    """
    responses = data.copy()

    # Iterate through the provided queries and align them with the session events
    for index, eval_entry in enumerate(responses):
      query = eval_entry["query"]
      actual_tool_uses = []
      response = None

      # Search for the corresponding session events
      for event in session_data.events:
        # Match the query to a user event
        if event.author == "user" and event.content.parts[0].text == query:
          # Look for subsequent tool usage or model responses
          for subsequent_event in session_data.events:
            if subsequent_event.invocation_id == event.invocation_id:
              # Extract tool usage
              if subsequent_event.content.parts[0].function_call:
                call = subsequent_event.content.parts[0].function_call
                actual_tool_uses.append(
                    {"tool_name": call.name, "tool_input": call.args}
                )
              # Extract final response
              elif subsequent_event.author != "user":
                response = subsequent_event.content.parts[0].text

      # Update the results for the current query
      responses[index]["actual_tool_use"] = actual_tool_uses
      responses[index]["response"] = response
    return responses

  @staticmethod
  def before_tool_callback(tool, args, tool_context, eval_dataset):
    """
    Intercept specific tool calls and return predefined outputs
    from eval_dataset.
    """
    for index, eval_entry in enumerate(eval_dataset):
      expected_tool_use = eval_entry.get("expected_tool_use", [])
      for expected in expected_tool_use:
        if (
            EvalConstants.MOCK_TOOL_OUTPUT in expected
            and tool.name == expected[EvalConstants.TOOL_NAME]
            and args == expected.get(EvalConstants.TOOL_INPUT, {})
        ):
          # pop the matched entry so we don't rematch again
          eval_dataset.pop(index)
          return {"result": expected[EvalConstants.MOCK_TOOL_OUTPUT]}

    return None

  @staticmethod
  def apply_before_tool_callback(
      agent: BaseAgent, callback: BeforeToolCallback, all_mock_tools: set[str]
  ):
    """
    Recursively apply the before_tool_callback to the root agent and all its subagents.
    """
    # check if the agent has tools that defined by evalset
    # We use function name to check if tools match
    for tool in agent.tools:
      if tool.__name__ in all_mock_tools:
        agent.before_tool_callback = callback

    # Apply recursively to subagents if they exist
    if hasattr(agent, "children") and isinstance(agent.children, list):
      for child_agent in agent.children:
        EvaluationGenerator.apply_before_tool_callback(
            child_agent, callback, all_mock_tools
        )
