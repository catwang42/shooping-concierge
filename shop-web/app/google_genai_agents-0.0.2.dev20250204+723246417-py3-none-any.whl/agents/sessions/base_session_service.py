import abc
from typing import Any
from typing import Optional

from pydantic import BaseModel
from pydantic import Field

from ..events import Event
from .session import Session


class PendingEvent(BaseModel):
  """Represents a pending function call event and its associated response events."""

  function_call_event: Event
  function_response_events: list[Event] = Field(default_factory=list)


class GetSessionConfig(BaseModel):
  num_recent_events: int | None = None
  after_timestamp: float | None = None


class ListEventsConfig(BaseModel):
  query: str | None = None
  page_size: int | None = None
  page_token: str | None = None


class ListSessionsResponse(BaseModel):
  session_ids: list[str] = []


class ListEventsResponse(BaseModel):
  events: list[Event] = []
  next_page_token: str | None = None


class BaseSessionService(abc.ABC):

  @abc.abstractmethod
  def create(
      self,
      app_name: str,
      user_id: str,
      state: Optional[dict[str, Any]] = None,
      *,
      session_id: Optional[str] = None,
  ) -> Session:
    """Creates a new session.

    Args:
      app_name: the name of the app.
      user_id: the id of the user.
      state: the initial state of the session.
      session_id: the client-provided id of the session. If not provided, a
        server-side generated uuid will be used.

    Returns:
      session: The newly created session instance.
    """
    pass

  @abc.abstractmethod
  def get(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      config: GetSessionConfig | None = None,
  ) -> Session | None:
    """Gets a session."""
    pass

  @abc.abstractmethod
  def list_sessions(self, app_name: str, user_id: str) -> ListSessionsResponse:
    """Lists all the session IDs."""
    pass

  @abc.abstractmethod
  def delete(self, app_name: str, user_id: str, session_id: str) -> None:
    """Deletes a session."""
    pass

  @abc.abstractmethod
  def list_events(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      config: ListEventsConfig,
  ) -> ListEventsResponse:
    """Lists events in a session."""
    pass

  @abc.abstractmethod
  def list_pending_events(
      self, app_name: str, user_id: str, session_id: str
  ) -> list[PendingEvent]:
    """Lists pending events in a session."""
    pass

  def append_event(self, session: Session, event: Event) -> Event:
    """Appends an event to a session."""
    if event.actions:
      if event.actions.state_delta:
        session.state.update(event.actions.state_delta)

    session.events.append(event)
    return event
