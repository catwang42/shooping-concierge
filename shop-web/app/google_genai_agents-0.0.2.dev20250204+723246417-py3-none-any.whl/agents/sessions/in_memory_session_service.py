import copy
import time
from typing import Any
from typing import Optional
import uuid

from typing_extensions import override

from ..events import Event
from .base_session_service import BaseSessionService
from .base_session_service import GetSessionConfig
from .base_session_service import ListEventsConfig
from .base_session_service import ListEventsResponse
from .base_session_service import ListSessionsResponse
from .base_session_service import PendingEvent
from .session import Session


class InMemorySessionService(BaseSessionService):

  # A map from app name to a map from user Id to a map from user Id to a map
  # from session ID to a map from function call event ID to pending event.
  pending_events: dict[str, dict[str, dict[str, dict[str, PendingEvent]]]] = {}
  # A map from app name to a map from user ID to a map from session ID to session.
  sessions: dict[str, dict[str, dict[str, Session]]] = {}

  @override
  def create(
      self,
      app_name: str,
      user_id: str,
      state: Optional[dict[str, Any]] = None,
      *,
      session_id: Optional[str] = None,
  ) -> Session:
    session_id = (
        session_id.strip()
        if session_id and session_id.strip()
        else str(uuid.uuid4())
    )
    session = Session(
        app_name=app_name,
        user_id=user_id,
        id=session_id,
        state=state or {},
        last_update_time=time.time(),
    )

    if app_name not in self.sessions:
      self.sessions[app_name] = {}
    if user_id not in self.sessions[app_name]:
      self.sessions[app_name][user_id] = {}
    self.sessions[app_name][user_id][session_id] = session
    return copy.deepcopy(session)

  def exists(self, app_name: str, user_id: str, session_id: str) -> bool:
    if app_name not in self.sessions:
      return False
    if user_id not in self.sessions[app_name]:
      return False
    return session_id in self.sessions[app_name][user_id]

  @override
  def get(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      config: GetSessionConfig | None = None,
  ) -> Session:
    if app_name not in self.sessions:
      return None
    if user_id not in self.sessions[app_name]:
      return None
    if session_id not in self.sessions[app_name][user_id]:
      return None

    session = self.sessions[app_name][user_id].get(session_id)
    if config:
      if config.num_recent_events:
        session.events = session.events[-config.num_recent_events :]
      elif config.after_timestamp:
        i = len(session.events) - 1
        while i >= 0:
          if session.events[i].timestamp < config.after_timestamp:
            break
          i -= 1
        if i >= 0:
          session.events = session.events[i:]
    return copy.deepcopy(session)

  def list_sessions(self, app_name: str, user_id: str) -> ListSessionsResponse:
    empty_response = ListSessionsResponse()
    if app_name not in self.sessions:
      return empty_response
    if user_id not in self.sessions[app_name]:
      return empty_response
    return ListSessionsResponse(
        session_ids=list(self.sessions[app_name][user_id])
    )

  def delete(self, app_name: str, user_id: str, session_id: str) -> None:
    if self.get(app_name, user_id, session_id) is None:
      return None

    self.sessions[app_name][user_id].pop(session_id)

  @override
  def append_event(self, session: Session, event: Event) -> Event:
    # Update the in-memory session.
    super().append_event(session, event)
    session.last_update_time = event.timestamp

    # Update the storage session
    app_name = session.app_name
    user_id = session.user_id
    session_id = session.id
    if app_name not in self.sessions:
      return event
    if user_id not in self.sessions[app_name]:
      return event
    if session_id not in self.sessions[app_name][user_id]:
      return event

    storage_session = self.sessions[app_name][user_id].get(session_id)
    super().append_event(storage_session, event)

    if event.actions:
      if event.get_function_calls() and event.actions.pending:
        pending_event = PendingEvent(function_call_event=event)
        if session.app_name not in self.pending_events:
          self.pending_events[session.app_name] = {}
        if session.user_id not in self.pending_events[session.app_name]:
          self.pending_events[session.app_name][session.user_id] = {}
        if (
            session.id
            not in self.pending_events[session.app_name][session.user_id]
        ):
          self.pending_events[session.app_name][session.user_id][
              session.id
          ] = {}
        self.pending_events[session.app_name][session.user_id][session.id][
            event.id
        ] = pending_event
      if event.get_function_responses() and not event.actions.pending:
        # TODO: Properly handle parallel function calls.
        if (
            session.app_name in self.pending_events
            and session.user_id in self.pending_events[session.app_name]
            and session.id
            in self.pending_events[session.app_name][session.user_id]
        ):
          self.pending_events[session.app_name][session.user_id][
              session.id
          ].pop(event.function_call_event_id, None)

    storage_session.last_update_time = event.timestamp
    return event

  @override
  def list_events(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      config: ListEventsConfig,
  ) -> ListEventsResponse:
    raise NotImplementedError()

  def list_pending_events(
      self, app_name: str, user_id: str, session_id: str
  ) -> list[PendingEvent]:
    if (
        app_name in self.pending_events
        and user_id in self.pending_events[app_name]
        and session_id in self.pending_events[app_name][user_id]
    ):
      return list(self.pending_events[app_name][user_id][session_id].values())
    else:
      return []
