from typing import Optional

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field


class EventActions(BaseModel):
  model_config = ConfigDict(extra='forbid')

  skip_summarization: Optional[bool] = None
  """If true, it won't call model to summarize function response.

  Only used for function_response event.
  """

  state_delta: dict[str, object] = Field(default_factory=dict)
  """Indicates that the event is updating the state with the given delta."""

  artifact_delta: dict[str, int] = Field(default_factory=dict)
  """Indicates that the event is updating an artifact. key is the filename,
  value is the version."""

  pending: Optional[bool] = None
  """If true, the tool call is pending and the result is not yet available.

  Only used for function_call event.
  """

  transfer_to_agent: Optional[str] = None
  """If set, the event transfers to the specified agent."""

  escalate: Optional[bool] = None
  """The agent is escalating to a higher level agent."""
