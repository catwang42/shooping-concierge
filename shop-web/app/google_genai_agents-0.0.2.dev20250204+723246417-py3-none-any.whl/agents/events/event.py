from datetime import datetime
import os
import random
import string
from typing import Optional

from google.genai import types
from pydantic import ConfigDict
from pydantic import Field

from ..models.llm_response import LlmResponse
from .event_actions import EventActions


class Event(LlmResponse):
  model_config = ConfigDict(extra='forbid')

  # TODO: Change to required field after session files are all migrated.
  invocation_id: str | None = None
  # The name of the agent that sent the event, or user.
  author: str
  actions: EventActions = Field(default_factory=EventActions)
  # Whether this is a greeting message. When this is true, the content is not
  # sent to the model for future conversation. This is because we found that
  # the agent transfer rate is low when the greeting message is present. Perhaps
  # because the root_agent thinks it can handle all requests based on the
  # greeting message.
  is_greeting: bool | None = None

  function_call_event_id: Optional[str] = None
  """The ID of the function call event that this event is responding to."""

  # The following are computed fields.
  # No not assign the ID. It will be assigned by the session.
  id: str = ''
  timestamp: float = Field(default_factory=lambda: datetime.now().timestamp())

  def model_post_init(self, __context):
    # Generates a random ID for the event.
    if not self.id:
      self.id = Event.new_id()

  def is_final_response(self) -> bool:
    if self.actions.skip_summarization:
      return True
    return (
        not self.get_function_calls()
        and not self.get_function_responses()
        and not self.partial
        and not self.has_trailing_code_exeuction_result()
    )

  def get_function_calls(self) -> list[types.FunctionCall]:
    func_calls = []
    if self.content:
      for part in self.content.parts:
        if part.function_call:
          func_calls.append(part.function_call)
    return func_calls

  def get_function_responses(self) -> list[types.FunctionResponse]:
    func_response = []
    if self.content:
      for part in self.content.parts:
        if part.function_response:
          func_response.append(part.function_response)
    return func_response

  def has_trailing_code_exeuction_result(
      self,
  ) -> bool:
    if self.content:
      if self.content.parts:
        return self.content.parts[-1].code_execution_result is not None
    return False

  @classmethod
  def new_id(cls):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(8))

  @classmethod
  def from_function_response(
      cls, function_call_event, function_call, function_result
  ):
    content = types.Content(
        role='user',
        parts=[
            types.Part(
                function_response=types.FunctionResponse(
                    name=function_call.name, response=function_result
                )
            )
        ],
    )
    return cls(
        invocation_id=function_call_event.invocation_id,
        author=function_call_event.author,
        content=content,
        function_call_event_id=function_call_event.id,
    )

  @classmethod
  def from_llm_response(
      cls, id: str, invocation_id: str, author: str, llm_response: LlmResponse
  ):
    event_dict = llm_response.model_dump(exclude_none=True)
    event_dict['id'] = id
    event_dict['invocation_id'] = invocation_id
    event_dict['author'] = author
    return cls.model_validate(event_dict)
