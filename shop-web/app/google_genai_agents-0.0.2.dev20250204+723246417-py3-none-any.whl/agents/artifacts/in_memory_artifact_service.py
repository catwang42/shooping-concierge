import logging

from google.genai import types
from pydantic import BaseModel
from pydantic import Field

from ..events import Event
from .base_artifact_service import BaseArtifactService

logger = logging.getLogger(__name__)


class InMemoryArtifactService(BaseArtifactService, BaseModel):

  artifacts: dict[str, dict[str, list[types.Part]]] = Field(
      default_factory=dict
  )

  def save(
      self,
      session_id: str,
      filename: str,
      artifact: types.Part,
  ) -> int:
    if session_id not in self.artifacts:
      self.artifacts[session_id] = {}

    if filename not in self.artifacts[session_id]:
      self.artifacts[session_id][filename] = []

    version = len(self.artifacts[session_id][filename])
    self.artifacts[session_id][filename].append(artifact)
    return version

  def load(
      self, session_id: str, filename: str, version: int | None = None
  ) -> types.Part | None:
    if not self.artifacts.get(session_id):
      return None

    versions = self.artifacts[session_id].get(filename)
    if not versions:
      return None

    if version is None:
      version = -1
    return versions[version]

  def list_keys(self, session_id: str) -> list[str]:
    if not self.artifacts.get(session_id):
      return []

    return list(self.artifacts[session_id].keys())

  def delete(self, session_id: str, filename: str) -> None:
    if not self.artifacts.get(session_id):
      return None
    self.artifacts[session_id].pop(filename, None)


  def list_versions(
      self, session_id: str, filename: str
  ) -> list[int]:
    if not self.artifacts.get(session_id):
      return []

    versions = self.artifacts[session_id][filename]
    return list(range(len(versions)))
