import sys
import time
import types

import streamlit as st

from agents.agents.agent import Agent
from agents.artifacts import InMemoryArtifactService
from agents.runners import Runner
from agents.sessions.base_session_service import BaseSessionService
from agents.sessions.in_memory_session_service import InMemorySessionService
from agents.sessions.postgres_session_service import PostgresSessionService

CONNECT_REMOTE_SERVER_DEMO_NAME = 'Connect to Remote Server'


@st.cache_resource
def get_remote_server_urls():
  remote_urls = set()
  return remote_urls


@st.cache_resource
def get_session_service() -> BaseSessionService:
  db_url = sys.argv[2]
  if db_url:
    return PostgresSessionService(db_url=db_url)
  else:
    return InMemorySessionService()


@st.cache_resource
def get_artifact_service():
  return InMemoryArtifactService()


def _get_runner(agent_name: str):
  return Runner(
      agent_name,
      get_demo_modules()[agent_name].agent.root_agent,
      get_artifact_service(),
      get_session_service(),
      response_modalities=st.session_state.response_modalities,
  )


def get_runner() -> Runner:
  """Gets the runner for the current selected agent."""
  return _get_runner(_get_root_agent_name())


@st.cache_resource
def get_agent_folder():
  agent_folder = sys.argv[1]
  if agent_folder not in sys.path:
    sys.path.append(agent_folder)
  return agent_folder


@st.cache_resource
def get_demo_modules() -> dict[str, types.ModuleType]:
  demo_modules = {}
  return demo_modules


def setup_session_state():
  if 'artifact_service' not in st.session_state:
    st.session_state.artifact_service = get_artifact_service()
  if 'session_service' not in st.session_state:
    st.session_state.session_service = get_session_service()
  if 'event_dialog_index' not in st.session_state:
    st.session_state.event_dialog_index = 0
  if 'file_uploader_key' not in st.session_state:
    st.session_state.file_uploader_key = str(time.time())
  if 'event_num' not in st.session_state:
    st.session_state.event_num = 0
  if 'edit_state' not in st.session_state:
    st.session_state.edit_state = False
  if 'demo_name' not in st.session_state:
    st.session_state.demo_name = None
  if 'streaming' not in st.session_state or st.session_state.streaming is None:
    st.session_state.streaming = ''
  if 'call_llm_spans' not in st.session_state:
    st.session_state.call_llm_spans = {}
  if 'is_live' not in st.session_state:
    st.session_state.is_live = False
  if 'response_modalities' not in st.session_state:
    st.session_state.response_modalities = None


def _get_root_agent_name() -> str:
  return st.session_state.demo_name


def get_root_agent() -> Agent:
  return get_demo_modules()[_get_root_agent_name()].agent.root_agent


def is_remote_mode() -> bool:
  """Whether it's running in remote mode via an api server."""
  demo_name: str = st.session_state.demo_name
  return bool(demo_name) and demo_name.startswith('http://')
