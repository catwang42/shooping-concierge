import asyncio
import logging
import wave

from google.genai import types
import pyaudio
import streamlit as st

from ...agents import LiveRequestQueue
from . import app_context

logger = logging.getLogger(__name__)
FORMAT = pyaudio.paInt16
CHANNELS = 1
SEND_SAMPLE_RATE = 16000
CHUNK_SIZE = 1024
AUDIO_FILE_PATH = "user_audio_streaming.wav"


class AudioStreamingComponent:

  def __init__(self, sample_rate=16000, channels=1, chunk_size=1024):
    self.sample_rate = sample_rate
    self.channels = channels
    self.chunk_size = chunk_size
    self.audio_interface = pyaudio.PyAudio()
    self.audio_stream = None
    self.live_request_queue = LiveRequestQueue()
    # for debugging or replay audio
    self.recorded_frames = []
    self.is_streaming = False

    self.audio_data = []
    self.streaming_audio_data = []

  async def start_streaming(self):
    """Start audio streaming using PyAudio."""
    self.is_streaming = True
    self.recorded_frames = []
    mic_info = self.audio_interface.get_default_input_device_info()
    self.audio_stream = self.audio_interface.open(
        format=FORMAT,
        channels=self.channels,
        rate=self.sample_rate,
        input=True,
        input_device_index=mic_info["index"],
        frames_per_buffer=self.chunk_size,
    )
    while True:
      # TODO: temoporary fix for input overflow.
      # exception_on_overflow=False may cause minior frame loss
      frame = self.audio_stream.read(
          self.chunk_size, exception_on_overflow=False
      )
      if frame:
        self._buffer_streaming_data(frame)
        await asyncio.sleep(0)

  def stop_streaming(self):
    """Stop audio streaming and close resources."""
    if self.audio_stream and self.is_streaming:
      self.is_streaming = False
      self.audio_stream.stop_stream()
      self.audio_stream.close()

  def save_to_file(self, file_path):
    """Save the recorded audio to a WAV file."""
    if not self.recorded_frames:
      return False
    with wave.open(file_path, "wb") as wf:
      wf.setnchannels(self.channels)
      wf.setsampwidth(self.audio_interface.get_sample_size(FORMAT))
      wf.setframerate(self.sample_rate)
      wf.writeframes(b"".join(self.recorded_frames))
    return True

  def _buffer_streaming_data(self, in_data):
    """Callback to buffer audio chunks and store them."""
    self.live_request_queue.send_realtime(
        types.Blob(data=in_data, mime_type="audio/pcm")
    )
    self.recorded_frames.append(in_data)
    return (None, pyaudio.paContinue)

  def close(self):
    self.audio_interface.terminate()


def render():
  # Initialize Streamlit session state variables
  if "audio_data_queue" not in st.session_state:
    st.session_state.audio_data_queue = (
        asyncio.Queue()
    )  # Queue for streaming audio input
  if "runner_output_queue" not in st.session_state:
    st.session_state.runner_output_queue = (
        asyncio.Queue()
    )  # Queue for model server responses
  if "stop_event" not in st.session_state:
    st.session_state.stop_event = asyncio.Event()  # Event to stop streaming
  if "audio_streaming_component" not in st.session_state:
    st.session_state.audio_streaming_component = AudioStreamingComponent()


def stop_runner():
  st.session_state.stop_event.set()  # Signal stop to the runner
  st.session_state.audio_streaming_component.stop_streaming()
