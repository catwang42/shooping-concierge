import json
import logging
import os

import pandas as pd
import streamlit as st

from agents.sessions.session import Session

from . import app_context
from . import chat

logger = logging.getLogger(__name__)


def render():
  if not st.session_state.demo_name:
    return

  # Render current agent name
  current_agent = st.session_state.get('demo_name', None)

  if not current_agent:
    st.info('Please select an agent first in Agent tab.')
    return

  if st.button('Save session as eval', use_container_width=True):
    save_session_as_test_file_dialog()

  # Render evaluation file selection
  select_evaluations()

  if not st.session_state.get('run_tests'):
    render_eval_results()
  st.session_state['run_tests'] = False

  # Load Selected Session
  load_session_with_eval()


def select_evaluations():
  col1, col2 = st.columns(2)
  if col1.button(
      'Run Select',
      use_container_width=True,
      key='open_test_files_popup',
  ):
    select_test_files_popup()

  if col2.button(
      'Run All',
      use_container_width=True,
      key='run_all_tests_button',
  ):
    eval_files_directory = os.path.abspath(
        os.path.join(app_context.get_agent_folder(), st.session_state.demo_name)
    )
    all_test_files = [
        os.path.join(root, file)
        for root, _, files in os.walk(eval_files_directory)
        for file in files
        if file.endswith('.test.json')
    ]
    st.session_state['run_tests'] = True
    st.session_state['test_file_selection'] = all_test_files

  # Run the selected test files
  if st.session_state.get('run_tests'):
    run_tests(st.session_state.get('test_file_selection', []))


def load_session_with_eval():
  if (
      'session_to_load' in st.session_state
      and st.session_state['session_to_load']
  ):

    st.write(f"✅ Loading session: {st.session_state['session_to_load']}")
    selected_eval_file = st.session_state['session_to_load']
    session_name = selected_eval_file.rsplit('.test', 1)[0]

    session_path = os.path.join(
        app_context.get_agent_folder(),
        st.session_state.demo_name,
        session_name + '.session.json',
    )

    eval_path = os.path.join(
        app_context.get_agent_folder(),
        st.session_state.demo_name,
        session_name + '.test.json',
    )

    # Check if the session file exists
    if not os.path.exists(session_path) or not os.path.exists(eval_path):
      st.error(f'❌ File not found: {session_path}')
      st.session_state['session_to_load'] = None  # Clear temporary state
      return

    with open(session_path, 'r') as f:
      st.session_state.session = Session.model_validate_json(f.read())

    with open(eval_path, 'r') as f:
      st.session_state.eval = json.load(f)
      logger.info('loaded eval file: %s', eval_path)

    st.session_state['session_to_load'] = None  # Clear temporary state
    st.rerun()


def run_tests(test_files):
  if not test_files:
    st.warning('No files selected for testing.')
    return

  progress_section = st.empty()
  with progress_section.container():
    st.write('### Running Evaluations')
    progress = st.progress(0)
  total_files = len(test_files)
  test_results = []

  col1, col2 = st.columns([8, 2])
  col1.text('File')
  col2.text('Result')

  for idx, file_path in enumerate(test_files):
    try:
      # Load evaluation criteria for the current file
      from agents.evaluation.agent_evaluator import AgentEvaluator
      from agents.evaluation.trajectory_evaluator import TrajectoryEvaluator

      evaluation_criteria = AgentEvaluator.find_config_for_test_file(file_path)

      # Use AgentEvaluator for trajectory evaluation
      dataset = AgentEvaluator.load_dataset(file_path)[0]
      agent_name = st.session_state.get('demo_name', 'unknown_agent')

      # breakpoint()
      session_name = file_path.rsplit('.test.json', 1)[0]

      session_path = os.path.join(
          app_context.get_agent_folder(),
          st.session_state.demo_name,
          session_name + '.session.json',
      )

      num_runs = 1
      # Check if the session file exists
      evaluation_response = None
      if os.path.exists(session_path):
        evaluation_response = AgentEvaluator._generate_responses_from_session(
            [dataset], session_path
        )
      else:
        evaluation_response = AgentEvaluator._generate_responses(
            agent_name, [dataset], num_runs=num_runs
        )
      score = TrajectoryEvaluator.evaluate(evaluation_response)

      # Check against criteria
      threshold = evaluation_criteria.get('tool_trajectory_avg_score', 1.0)
      result = '✅' if score >= threshold else '❌'
    except Exception as e:
      result = f'❌ Error - {str(e)}'
      logger.info('Error: %s', str(e))

    # Append results
    test_result = {
        'File Name': os.path.basename(file_path),
        'Result': result,
        'File Path': file_path,
    }
    test_results.append(test_result)
    render_eval_result(idx, test_result)
    # Update progress
    progress.progress((idx + 1) / total_files)

  st.session_state['test_results'] = test_results
  progress_section.empty()


def render_eval_results():
  if (
      'test_results' not in st.session_state
      or not st.session_state['test_results']
  ):
    st.info('Run an evaluation to see results.')
    return
  col1, col2 = st.columns([8, 2])
  col1.text('File')
  col2.text('Result')

  test_results_df = pd.DataFrame(st.session_state['test_results'])

  for index, row in test_results_df.iterrows():
    render_eval_result(index, row)


def render_eval_result(index, row):
  col1, col2 = st.columns([8, 2])
  with col1:
    st.write(row['File Name'].removesuffix('.test.json'))
  with col2:
    if st.button(row['Result'], key=f'load_session_btn_{index}'):
      file_path = row['File Path']
      st.session_state['session_to_load'] = os.path.splitext(
          os.path.basename(file_path)
      )[0]


# File Selection Dialog
@st.dialog('Select Evaluation Files to Run')
def select_test_files_popup():
  st.write('### Select Files for Evaluation')

  # Fetch test files
  eval_files_directory = os.path.abspath(
      os.path.join(app_context.get_agent_folder(), st.session_state.demo_name)
  )
  test_files = [
      os.path.join(root, file)
      for root, _, files in os.walk(eval_files_directory)
      for file in files
      if file.endswith('.test.json')
  ]

  if not test_files:
    st.warning('No test files found.')
    return

  # Prepare selection table
  test_data = {
      'Select': [
          os.path.basename(file)
          in st.session_state.get('test_file_selection', [])
          for file in test_files
      ],
      'File Name': [os.path.basename(file) for file in test_files],
  }
  test_df = pd.DataFrame(test_data)

  # Display editable table
  edited_test_df = st.data_editor(
      test_df, use_container_width=True, key='test_file_selection_table'
  )

  # Update selected test files
  st.session_state['test_file_selection'] = [
      test_files[i]
      for i, selected in enumerate(edited_test_df['Select'])
      if selected
  ]

  if st.button('Run Selected Tests'):
    st.session_state['run_tests'] = True
    st.session_state['run_all_tests'] = (
        False  # Ensure only selected tests are run
    )
    st.rerun()


@st.dialog('Save session as test file')
def save_session_as_test_file_dialog():
  session_name = st.text_input(
      'Test file name',
      value=st.session_state.selected_session,
      key='session_name_input',
  )
  save_button_clicked = st.button('Save', key='test_file_save_button')

  if save_button_clicked:
    try:
      # Convert the session data to evaluation format
      test_data = convert_session_format_to_eval_format(
          st.session_state.session.model_dump()
      )

      # Serialize the test data to JSON
      test_data_str = json.dumps(test_data, indent=2)

      # Define the file path
      test_file_path = os.path.join(
          app_context.get_agent_folder(),
          st.session_state.demo_name,
          session_name + '.test.json',
      )

      # Write the JSON string to the file
      with open(test_file_path, 'w') as f:
        f.write(test_data_str)

      # Provide feedback on the UI
      st.success(f'File saved successfully as: {test_file_path}')

    except Exception as e:
      # Display an error message if something goes wrong
      st.error(f'An error occurred while saving the file: {str(e)}')


def load_eval_into_session(session, i, eval_dataset_index, actual_tools):
  def render_eval_event(event_index, author, eval_event_index, tools_match):
    eval_event = st.session_state.eval[eval_event_index]
    expected_tools = eval_event.get('expected_tool_use', [])

    # Create a new row for the evaluation
    chat_row = st.container(key=f'chat_row_eval_{event_index}')
    with chat_row:
      # Render the avatar for the evaluation
      chat.render_avatar(author, event_index, 0)
      with st.container():
        if not tools_match:
          st.markdown('**Evaluation (❌): Mismatch Detected**')
        else:
          if expected_tools:
            st.markdown('**Evaluation (✅): Expected Tools Used**')
          else:
            return  # If no expected tools, return early

        # Render tools in a horizontal layout
        for tool_index, tool in enumerate(expected_tools):
          render_eval_tool_button(eval_event_index, tool, tool_index)

  @st.fragment
  def render_eval_tool_button(eval_event_index, tool, tool_index):
    tool_text = f"⚡ {tool.get('tool_name', 'Unknown Tool')}"
    tool_details = tool.get('tool_input', {})
    unique_key = (
        f'eval_tool_{eval_event_index}_{tool.get("tool_name")}_{tool_index}'
    )

    # Render the popup and button
    with st.popover(tool_text):
      st.write('### Tool Details')
      st.json(tool_details)
      st.button(
          tool_text,
          key=unique_key,
          help='Click to view details',  # Optional tooltip
          on_click=lambda: None,  # Trigger the popup display
      )

  if 'eval' not in st.session_state:
    return
  if i - 1 >= 0 and session.events[i - 1].author == 'user':
    eval_event = st.session_state.eval[eval_dataset_index]
    expected_tools = eval_event.get('expected_tool_use', [])
    if not expected_tools:
      eval_dataset_index += 1
      actual_tools = []
      return eval_dataset_index
    from agents.evaluation.trajectory_evaluator import TrajectoryEvaluator

    actual_processed = [
        {'tool_name': tool.name, 'tool_input': tool.args}
        for tool in actual_tools
    ]
    expected_processed = [
        {'tool_name': tool['tool_name'], 'tool_input': tool['tool_input']}
        for tool in expected_tools
    ]
    tools_match = TrajectoryEvaluator.are_tools_equal(
        actual_processed, expected_processed
    )

    render_eval_event(i, 'evaluation', eval_dataset_index, tools_match)

    eval_dataset_index += 1
    actual_tools = []
    return eval_dataset_index
  return eval_dataset_index


def convert_session_format_to_eval_format(session_file):
  """Converts a single session file in the new format into the accepted evaluation format.

  Args:
      session_file (dict): The detailed session log.

  Returns:
      list: A single evaluation dataset in the required format.
  """
  eval_case = []
  events = session_file.get('events', [])

  for event in events:
    if event.get('author') == 'user':
      # Extract user query
      content = event.get('content', {})
      parts = content.get('parts', [])
      if not parts:
        continue

      query = parts[0].get('text', '')  # Safely get the query text

      # Find the corresponding tool usage or response for the query
      expected_tool_use = []
      reference = None

      # Check subsequent events to extract tool uses or responses
      for subsequent_event in events[events.index(event) + 1 :]:
        subsequent_content = subsequent_event.get('content', {})
        subsequent_parts = subsequent_content.get('parts', [])
        if not subsequent_parts:
          continue

        # Safely check for function_call
        function_call = subsequent_parts[0].get('function_call', None)
        if function_call:
          tool_name = function_call.get('name', '')
          tool_input = function_call.get('args', {})
          expected_tool_use.append({
              'tool_name': tool_name,
              'tool_input': tool_input,
          })
        elif 'text' in subsequent_parts[0]:
          reference = subsequent_parts[0].get('text', '')
          break

      eval_case.append({
          'query': query,
          'expected_tool_use': expected_tool_use,
          'reference': reference,
      })

  return eval_case
