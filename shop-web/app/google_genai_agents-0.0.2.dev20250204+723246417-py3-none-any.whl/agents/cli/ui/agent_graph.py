from typing import Callable

import graphviz

from agents.agents import BaseAgent
from agents.tools import BaseTool
from agents.tools.agent_tool import AgentTool
from agents.tools.retrieval.base_retrieval_tool import BaseRetrievalTool


def build_graph(graph, agent, highlight_pairs):
  dark_green = '#6aa84f'
  light_green = '#d9ead3'

  def get_node_name(tool_or_agent):
    if isinstance(tool_or_agent, BaseAgent):
      return tool_or_agent.name
    elif isinstance(tool_or_agent, Callable):
      return tool_or_agent.__name__
    elif isinstance(tool_or_agent, BaseTool):
      return tool_or_agent.name
    else:
      raise ValueError(f'Unsupported tool type: {tool_or_agent}')

  def get_node_caption(tool_or_agent):
    if isinstance(tool_or_agent, BaseAgent):
      return '🤖 ' + tool_or_agent.name
    elif isinstance(tool_or_agent, Callable):
      return '🔧 ' + tool_or_agent.__name__
    elif isinstance(tool_or_agent, BaseRetrievalTool):
      return '🔎 ' + tool_or_agent.name
    elif isinstance(tool_or_agent, AgentTool):
      return '🤖 ' + tool_or_agent.name
    elif isinstance(tool_or_agent, BaseTool):
      return '🔧 ' + tool_or_agent.name
    else:
      raise ValueError(f'Unsupported tool type: {type(tool)}')

  def get_node_shape(tool_or_agent):
    if isinstance(tool_or_agent, BaseAgent):
      return 'ellipse'
    elif isinstance(tool_or_agent, Callable):
      return 'box'
    elif isinstance(tool_or_agent, BaseRetrievalTool):
      return 'cylinder'
    elif isinstance(tool_or_agent, BaseTool):
      return 'box'
    else:
      raise ValueError(f'Unsupported tool type: {type(tool_or_agent)}')

  def draw_node(tool_or_agent):
    name = get_node_name(tool_or_agent)
    shape = get_node_shape(tool_or_agent)
    caption = get_node_caption(tool_or_agent)
    if highlight_pairs:
      for highlight_tuple in highlight_pairs:
        if name in highlight_tuple:
          graph.node(
              name,
              caption,
              style='filled,rounded',
              fillcolor=light_green,
              color=dark_green,
              shape=shape,
          )
          return
    # if not in highlight, draw non-highliht node
    graph.node(name, caption, shape=shape, style='rounded')

  def draw_edge(from_name, to_name):
    if highlight_pairs:
      for highlight_from, highlight_to in highlight_pairs:
        if from_name == highlight_from and to_name == highlight_to:
          graph.edge(from_name, to_name, color=dark_green)
          return
        elif from_name == highlight_to and to_name == highlight_from:
          graph.edge(from_name, to_name, color=dark_green, dir='back')
          return
    # if no need to highlight, color none
    graph.edge(from_name, to_name, arrowhead='none')

  draw_node(agent)
  if hasattr(agent, 'children'):
    for child in agent.children:
      build_graph(graph, child, highlight_pairs)
      draw_edge(agent.name, child.name)
  if hasattr(agent, 'tools'):
    for tool in agent.tools:
      draw_node(tool)
      draw_edge(agent.name, get_node_name(tool))


def get_agent_graph(root_agent, highlights_pairs):
  print('build graph')
  graph = graphviz.Digraph(graph_attr={'rankdir': 'LR'})
  build_graph(graph, root_agent, highlights_pairs)
  return graph
