import io
import logging

import streamlit as st
from PIL import Image

logger = logging.getLogger(__name__)


def render():
  if not st.session_state.demo_name:
    return

  artifact_service = st.session_state.artifact_service
  session_id = st.session_state.session.id

  filenames = artifact_service.list_keys(session_id)

  if not filenames:
    return

  for key in filenames:
    logger.info(f'Render artifacts key {key}')

    versions = artifact_service.list_versions(session_id, key)
    if not versions:
      pass

    with st.popover(key):
      tab_names = ['Latest']
      for i in range(len(versions) - 2, -1, -1):
        tab_names.append(str(i))
      version = st.segmented_control(
          'Versions',
          options=tab_names,
          key=key,
      )
      if not version:
        version = 'Latest'
      index = len(versions) - 1 - tab_names.index(version)
      artifact = artifact_service.load(session_id, key, versions[index])
      if artifact.inline_data:
        st.download_button(
            label='Download',
            data=artifact.inline_data.data,
            file_name=key,
            mime=artifact.inline_data.mime_type,
            key=f'download_{key}_{index}',
        )
      elif artifact.file_data:
        st.download_button(
            label='Download',
            data=artifact.file_data.file_uri,
            file_name=key,
            mime=artifact.file_data.mime_type,
            key=f'download_{key}_{index}',
        )
    render_artifact(artifact)


def render_artifact(artifact):
  # Renders the artifact.
  if artifact.inline_data:
    if artifact.inline_data.mime_type.startswith('image/'):
      st.image(Image.open(io.BytesIO(artifact.inline_data.data)), width=400)
    elif artifact.inline_data.mime_type.startswith('application/pdf'):
      # Don't try to render it.
      pass
    elif artifact.inline_data.mime_type.startswith('text/html'):
      st.components.v1.html(
          artifact.inline_data.data, height=500, scrolling=True
      )
    else:
      st.write(artifact.inline_data.data)
  elif artifact.file_data:
    if artifact.file_data.mime_type.startswith('text/html'):
      st.components.v1.html(
          artifact.file_data.file_uri, height=500, scrolling=True
      )
  else:
    st.code(artifact.text)
