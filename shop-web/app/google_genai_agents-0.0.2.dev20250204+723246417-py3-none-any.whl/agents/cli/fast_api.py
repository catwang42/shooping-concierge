import importlib
import logging
import sys
from typing import Any
from typing import Optional

from fastapi import FastAPI
from fastapi import HTTPException
from google.genai import types
from pydantic import BaseModel
from uvicorn.main import run as uvicorn_run

from ..agents import Agent
from ..artifacts import InMemoryArtifactService
from ..events import Event
from ..runners import Runner
from ..sessions.in_memory_session_service import InMemorySessionService
from ..sessions.postgres_session_service import PostgresSessionService
from ..sessions.session import Session
from .utils import envs

logger = logging.getLogger(__name__)


class AgentRunRequest(BaseModel):
  app_name: str
  user_id: str
  session_id: str
  new_message: types.Content


def run_fast_api(
    *,
    app_name: str,
    agent_dir: str,
    agent_name: str,
    session_db_url: str = "",
) -> None:
  if agent_dir not in sys.path:
    sys.path.append(agent_dir)

  agent_module = importlib.import_module(agent_name)
  root_agent: Agent = agent_module.agent.root_agent
  envs.load_dotenv_for_agent(agent_name, agent_dir)

  artifact_service = InMemoryArtifactService()
  if not session_db_url:
    session_service = InMemorySessionService()
  else:
    session_service = PostgresSessionService(db_url=session_db_url)
  app = FastAPI()

  runner = Runner(app_name, root_agent, artifact_service, session_service)

  @app.get(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}",
      response_model_exclude_none=True,
  )
  def get_session(app_name: str, user_id: str, session_id: str) -> Session:
    session = session_service.get(app_name, user_id, session_id)
    if not session:
      raise HTTPException(status_code=404, detail="Session not found")
    return session

  @app.get(
      "/apps/{app_name}/users/{user_id}/sessions",
      response_model_exclude_none=True,
  )
  def list_sessions(app_name: str, user_id: str) -> list[str]:
    return session_service.list_sessions(app_name, user_id).session_ids

  @app.post(
      "/apps/{app_name}/users/{user_id}/sessions/{session_id}",
      response_model_exclude_none=True,
  )
  def create_session(
      app_name: str,
      user_id: str,
      session_id: str,
      state: Optional[dict[str, Any]] = None,
  ) -> Session:
    if session_service.get(app_name, user_id, session_id) is not None:
      logger.warning("Session already exists: %s", session_id)
      raise HTTPException(
          status_code=400, detail=f"Session already exists: {session_id}"
      )

    logger.info("New session created: %s", session_id)
    return session_service.create(
        app_name, user_id, state, session_id=session_id
    )

  @app.delete("/apps/{app_name}/users/{user_id}/sessions/{session_id}")
  def delete_session(app_name: str, user_id: str, session_id: str):
    session_service.delete(app_name, user_id, session_id)

  @app.post("/agent/run", response_model_exclude_none=True)
  def agent_run(req: AgentRunRequest) -> list[Event]:
    # TODO: Implement SSE for event generator.
    session = session_service.get(req.app_name, req.user_id, req.session_id)
    if not session:
      raise HTTPException(status_code=404, detail="Session not found")

    events = list(runner.run(session=session, new_message=req.new_message))
    logger.info("Generated %s events in agent run: %s", len(events), events)
    return events

  uvicorn_run(app, host="0.0.0.0", log_config=None)
