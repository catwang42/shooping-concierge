import os
import shlex
import subprocess
import sys

import click
import streamlit.web.bootstrap as bootstrap
from dotenv import load_dotenv

from .cli import run_cli
from .fast_api import run_fast_api
from .utils import logs


@click.group()
def main():
  """Agent Framework CLI tools."""
  pass


@main.command("run")
@click.option(
    "--json_file",
    type=click.Path(
        exists=True, dir_okay=False, file_okay=True, resolve_path=True
    ),
    help=(
        "The json file in the agent folder, either a *.input.json or"
        " *.session.json."
    ),
)
@click.option(
    "--save_session",
    type=bool,
    is_flag=True,
    show_default=True,
    default=False,
    help="Whether to save the session to a json file on exit.",
)
@click.argument(
    "agent",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
)
def cli_run(agent: str, json_file: str, save_session: bool):
  """Run an interactive CLI for a certain agent."""
  logs.log_to_tmp_folder()

  agent_parent_folder = os.path.dirname(agent)
  agent_folder_name = os.path.basename(agent)

  run_cli(
      agent_parent_dir=agent_parent_folder,
      agent_folder_name=agent_folder_name,
      json_file_path=json_file,
      save_session=save_session,
  )


@main.command()
@click.option(
    "--launch_browser",
    is_flag=True,
    show_default=True,
    default=False,
    help="Whether to launch browser automatically.",
)
@click.option(
    "--log_to_tmp",
    is_flag=True,
    show_default=True,
    default=False,
    help=(
        "Whether to log to system temp folder instead of console. This is"
        " useful for local debugging."
    ),
)
@click.option("--session_db_url", help="The database URL to store the session.")
@click.argument(
    "agent_dir",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
    default=os.getcwd(),
)
def web(
    agent_dir: str,
    launch_browser: bool,
    log_to_tmp: bool,
    session_db_url: str = "",
):
  """Start the web app server to test multiple agents.

  AGENT_DIR: the directory of agents, where each sub-directory is a single
  agent. By default, it is the current working directory.
  """
  if log_to_tmp:
    logs.log_to_tmp_folder()
  else:
    logs.log_to_stderr()

  app_script_path = os.path.join(os.path.dirname(__file__), "web.py")

  flag_options = {"server.headless": not launch_browser}
  bootstrap.load_config_options(flag_options)
  bootstrap.run(
      app_script_path,
      False,
      [agent_dir, session_db_url],
      flag_options,
  )


@main.command("test")
@click.argument(
    "test_folder",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
)
def test_folder(test_folder: str):
  """Run all tests in a specified folder recursively."""
  # Convert the test folder to a relative Python module path
  base_dir = os.getcwd()
  rel_path = os.path.relpath(test_folder, start=base_dir)
  module_name = rel_path.replace(
      os.sep, "."
  )  # Convert path to module name format
  click.echo(f"Module name derived: {module_name}")

  # Add the project root to sys.path to ensure absolute imports
  project_root = os.path.abspath(base_dir)
  if project_root not in sys.path:
    sys.path.append(project_root)

  logs.log_to_stderr()
  load_dotenv(override=True, verbose=True)

  # Find all `.test.json` files recursively in the folder
  test_paths = []
  for root, _, files in os.walk(test_folder):
    for file in files:
      if file.endswith(".test.json"):
        test_paths.append(os.path.join(root, file))

  # Add folder itself for evaluation
  if test_paths:
    test_paths.append(test_folder)

  if not test_paths:
    click.echo(f"No test files or folders found in: {test_folder}")
    return

  click.echo(f"Found {len(test_paths)} tests in the folder: {test_folder}")

  # Results list to collect pass/fail information
  results = []

  # Run tests and display results
  for path in test_paths:
    if os.path.isdir(path):
      click.echo(f"Running tests in folder: {path}")
    else:
      click.echo(f"Running test file: {path}")
    try:
      from ..evaluation.agent_evaluator import AgentEvaluator

      result = AgentEvaluator.evaluate(module_name, path)
      click.echo(f"\u2705 {path}: {result}")
      results.append({"path": path, "status": "Passed", "details": result})
    except Exception as e:
      click.echo(f"\u274c {path}: Error - {e}")
      results.append({"path": path, "status": "Failed", "details": str(e)})

  # Display a summary after all tests are run
  click.echo("\nTest Summary:")
  total_tests = len(results)
  passed_tests = len([r for r in results if r["status"] == "Passed"])
  failed_tests = total_tests - passed_tests

  click.echo(f"Total tests run: {total_tests}")
  click.echo(f"\u2705 Passed: {passed_tests}")
  click.echo(f"\u274c Failed: {failed_tests}")


@main.command("api_server")
@click.option(
    "--log_to_tmp",
    is_flag=True,
    show_default=True,
    default=False,
    help=(
        "Whether to log to system temp folder instead of console. This is"
        " useful for local debugging."
    ),
)
@click.option("--session_db_url", help="The database URL to store the session.")
@click.argument(
    "agent",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
)
def cli_api_server(agent: str, log_to_tmp: bool, session_db_url: str = ""):
  """Start a FastAPI server for a certain agent."""
  if log_to_tmp:
    logs.log_to_tmp_folder()
  else:
    logs.log_to_stderr()

  agent_parent_folder = os.path.dirname(agent)
  agent_folder_name = os.path.basename(agent)

  run_fast_api(
      app_name=agent_folder_name,
      agent_dir=agent_parent_folder,
      agent_name=agent_folder_name,
      session_db_url=session_db_url,
  )


@main.command("deploy")
@click.option("--cloud_project_name", type=str)
@click.option("--service_name", type=str)
@click.option("--agent_name", type=str)
def cli_deploy(cloud_project_name: str, service_name: str, agent_name: str):
  """Deploy a FastAPI server for a certain agent to Cloud Run."""
  command = (
      f"gcloud run deploy {service_name} --source . --region=us-central1"
      " --no-allow-unauthenticated --set-env-vars"
      f" GOOGLE_GENAI_USE_VERTEXAI=1,GOOGLE_CLOUD_PROJECT={cloud_project_name},"
      f"AGENT_NAME={agent_name},GOOGLE_CLOUD_LOCATION=us-central1 --port=8000"
  )
  subprocess.run(shlex.split(command))
